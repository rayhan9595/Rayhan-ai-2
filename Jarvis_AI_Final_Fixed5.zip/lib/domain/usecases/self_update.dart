import '../../core/self_aware/self_analyzer.dart';
import '../../core/self_aware/self_generator.dart';
import '../../core/self_aware/self_tester.dart';
import '../../core/self_aware/self_deployer.dart';
import '../../core/self_aware/self_healer.dart';
import '../../core/ai_brain/response_generator.dart';

class SelfUpdateResult {
  late final bool success;
  late final String featureName;
  late final String message;
  late final String? deployedPath;

  SelfUpdateResult({
    required this.success,
    required this.featureName,
    required this.message,
    this.deployedPath,
  });
}

class SelfUpdateUseCase {
  final SelfAnalyzer _analyzer = SelfAnalyzer();
  final SelfGenerator _generator = SelfGenerator();
  final SelfTester _tester = SelfTester();
  final SelfDeployer _deployer = SelfDeployer();
  final SelfHealer _healer = SelfHealer();
  final ResponseGenerator _response = ResponseGenerator();

  Future<SelfUpdateResult> execute(String userRequest) async {
    try {
      final analysis = await _analyzer.analyze(userRequest);
      final code = await _generator.generate(analysis);
      final testResult = await _tester.runSandboxTest(code);

      if (!testResult.passed) {
        await _healer.attemptFix(analysis.featureName, testResult.errorMessage ?? '');
        return SelfUpdateResult(
          success: false,
          featureName: analysis.featureName,
          message: 'Test failed: ${testResult.errorMessage}',
        );
      }

      final deployResult = await _deployer.deploy(code, testResult);

      if (deployResult.success) {
        await _response.generateSelfUpdateConfirmation(analysis.featureName);
      }

      return SelfUpdateResult(
        success: deployResult.success,
        featureName: analysis.featureName,
        message: deployResult.success
          ? 'Feature "${analysis.featureName}" deployed successfully.'
          : 'Deployment failed: ${deployResult.errorMessage}',
        deployedPath: deployResult.deployedPath,
      );
    } catch (e) {
      return SelfUpdateResult(
        success: false,
        featureName: 'unknown',
        message: 'Self-update error: $e',
      );
    }
  }
}
