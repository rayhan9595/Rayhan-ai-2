import '../../core/ai_brain/intent_classifier.dart';
import '../../core/ai_brain/entity_extractor.dart';
import '../../core/ai_brain/response_generator.dart';
import '../../core/automation_engine/action_executor.dart';
import '../../core/memory/context_manager.dart';
import '../../services/permission/permission_router.dart';
import '../../data/models/automation.dart';

class VoiceCommandResult {
  late final bool success;
  late final String intent;
  late final String message;
  late final Map<String, dynamic>? data;

  VoiceCommandResult({
    required this.success,
    required this.intent,
    required this.message,
    this.data,
  });
}

class VoiceCommandUseCase {
  final IntentClassifier _classifier = IntentClassifier();
  final EntityExtractor _extractor = EntityExtractor();
  final ResponseGenerator _response = ResponseGenerator();
  final ActionExecutor _executor = ActionExecutor();
  final ContextManager _context = ContextManager();
  final PermissionRouter _permission = PermissionRouter();

  Future<VoiceCommandResult> execute(String command, {List<Map<String, String>>? chatHistory}) async {
    try {
      _context.addCommandToHistory(command);

      final intentResult = await _classifier.classify(command, chatHistory: chatHistory);
      final entities = _extractor.extract(intentResult.entities);

      if (intentResult.requiresPermission) {
        final permType = _inferPermissionType(intentResult.primaryIntent);
        final hasPermission = await _permission.checkAndRoute(permType);
        if (!hasPermission) {
          return VoiceCommandResult(
            success: false,
            intent: intentResult.primaryIntent,
            message: 'Permission denied for ${intentResult.primaryIntent}',
          );
        }
      }

      final result = await _executeIntent(intentResult.primaryIntent, entities);

      await _response.generate(
        intent: intentResult.primaryIntent,
        success: result.success,
        data: result.data,
      );

      return VoiceCommandResult(
        success: true,
        intent: intentResult.primaryIntent,
        message: _response.lastResponse,
        data: result.data,
      );
    } catch (e) {
      print('VoiceCommandUseCase Error: $e');
      return VoiceCommandResult(
        success: false,
        intent: 'error',
        message: 'An error occurred: $e',
      );
    }
  }

  String _inferPermissionType(String intent) {
    switch (intent) {
      case 'call_contact':
      case 'send_sms':
        return 'contacts';
      case 'open_app':
      case 'control_device':
        return 'system_alert_window';
      case 'camera_capture':
        return 'camera';
      case 'read_contacts':
        return 'contacts';
      case 'access_location':
        return 'location';
      default:
        return 'none';
    }
  }

  Future<ActionResult> _executeIntent(String intent, ExtractedEntities entities) async {
    final action = AutomationAction(type: intent, params: {});
    return await _executor.execute(action);
  }
}
