import '../../core/automation_engine/workflow_manager.dart';
import '../../data/models/workflow.dart';

class ExecuteWorkflowUseCase {
  final WorkflowManager _manager = WorkflowManager();

  Future<void> execute(Workflow workflow) async {
    await _manager.executeWorkflow(workflow);
  }

  Future<void> executeById(String workflowId) async {
    // Implementation would fetch workflow and execute
  }
}
