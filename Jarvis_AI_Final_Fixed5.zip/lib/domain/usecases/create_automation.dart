import 'package:uuid/uuid.dart';
import '../../data/models/automation.dart';
import '../../data/repositories/automation_repo.dart';

class CreateAutomationUseCase {
  final AutomationRepository _repository = AutomationRepository();

  Future<Automation> execute({
    required String name,
    String description = '',
    required String triggerType,
    required Map<String, dynamic> triggerConfig,
    List<Map<String, dynamic>> conditions = const [],
    required List<AutomationAction> actions,
    bool voiceConfirmation = true,
  }) async {
    final automation = Automation(
      id: const Uuid().v4(),
      name: name,
      description: description,
      triggerType: triggerType,
      triggerConfig: triggerConfig,
      conditions: conditions,
      actions: actions,
      voiceConfirmation: voiceConfirmation,
    );

    await _repository.insert(automation);
    return automation;
  }
}
