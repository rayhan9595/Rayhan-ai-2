import '../../core/memory/long_term_memory.dart';

class ManageMemoryUseCase {
  final LongTermMemory _ltm = LongTermMemory();

  Future<void> saveUserPreference(String key, dynamic value) async {
    await _ltm.store(key, value, category: 'preference', importance: 7);
  }

  Future<dynamic> getUserPreference(String key) async {
    return await _ltm.retrieve(key);
  }

  Future<void> rememberFact(String key, dynamic value, {int importance = 5}) async {
    await _ltm.store(key, value, category: 'fact', importance: importance);
  }

  Future<List<dynamic>> searchMemories(String query) async {
    final results = await _ltm.searchByCategory(query);
    return results.map((e) => e.value).toList();
  }
}
