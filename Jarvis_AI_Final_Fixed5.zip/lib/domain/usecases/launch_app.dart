import '../../core/memory/app_memory.dart';
import '../../services/device/app_launcher_service.dart';
import '../../services/permission/permission_router.dart';

class LaunchAppResult {
  late final bool success;
  late final String message;
  late final bool openedPlayStore;

  LaunchAppResult({
    required this.success,
    required this.message,
    this.openedPlayStore = false,
  });
}

class LaunchAppUseCase {
  final AppMemory _appMemory = AppMemory();
  final AppLauncherService _launcher = AppLauncherService();
  final PermissionRouter _permission = PermissionRouter();

  Future<LaunchAppResult> execute(String appName) async {
    final hasPermission = await _permission.checkAndRoute('query_apps');
    if (!hasPermission) {
      return LaunchAppResult(
        success: false,
        message: 'Permission denied',
      );
    }

    final packageName = await _appMemory.getPackageName(appName);

    if (packageName != null) {
      final success = await _launcher.launchApp(packageName);
      if (success) {
        await _appMemory.recordUsage(packageName);
        return LaunchAppResult(
          success: true,
          message: '$appName launched',
        );
      }
    }

    final found = await _launcher.findAndLaunchApp(appName);
    if (found) {
      return LaunchAppResult(
        success: true,
        message: '$appName launched via search',
      );
    }

    await _launcher.openPlayStore(appName);
    return LaunchAppResult(
      success: false,
      message: '$appName not found, opening Play Store',
      openedPlayStore: true,
    );
  }

  Future<void> saveAppNickname(String name, String packageName, {List<String>? nicknames}) async {
    await _appMemory.saveApp(
      displayName: name,
      packageName: packageName,
      nicknames: nicknames ?? [],
    );
  }
}
