class Reminder {
  late final String id;
  late final String title;
  late final String? description;
  late final DateTime triggerTime;
  late final bool isRecurring;
  late final String? recurrenceRule;
  late final String? location;
  late final double? latitude;
  late final double? longitude;
  late final bool isCompleted;
  late final String? category;
  late final int priority;

  Reminder({
    required this.id,
    required this.title,
    this.description,
    required this.triggerTime,
    this.isRecurring = false,
    this.recurrenceRule,
    this.location,
    this.latitude,
    this.longitude,
    this.isCompleted = false,
    this.category,
    this.priority = 3,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'trigger_time': triggerTime.toIso8601String(),
    'is_recurring': isRecurring ? 1 : 0,
    'recurrence_rule': recurrenceRule,
    'location': location,
    'latitude': latitude,
    'longitude': longitude,
    'is_completed': isCompleted ? 1 : 0,
    'category': category,
    'priority': priority,
  };

  factory Reminder.fromJson(Map<String, dynamic> json) => Reminder(
    id: json['id'],
    title: json['title'],
    description: json['description'],
    triggerTime: DateTime.parse(json['trigger_time']),
    isRecurring: json['is_recurring'] == 1,
    recurrenceRule: json['recurrence_rule'],
    location: json['location'],
    latitude: json['latitude'],
    longitude: json['longitude'],
    isCompleted: json['is_completed'] == 1,
    category: json['category'],
    priority: json['priority'] ?? 3,
  );
}
