import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class SQLiteDB {
  static final SQLiteDB _instance = SQLiteDB._internal();
  factory SQLiteDB() => _instance;
  SQLiteDB._internal();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  Future<Database> _initDB() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    final path = join(documentsDirectory.path, 'jarvis_db.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS automations (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        trigger_type TEXT NOT NULL,
        trigger_config TEXT,
        conditions TEXT,
        actions TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT,
        last_run TEXT,
        run_count INTEGER DEFAULT 0,
        voice_confirmation INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workflows (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        trigger_type TEXT NOT NULL,
        trigger_keyword TEXT,
        conditions TEXT,
        condition_logic TEXT DEFAULT 'AND',
        actions TEXT,
        is_active INTEGER DEFAULT 1,
        next_run_time TEXT,
        latitude REAL,
        longitude REAL,
        radius REAL,
        voice_confirmation INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS reminders (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        trigger_time TEXT NOT NULL,
        is_recurring INTEGER DEFAULT 0,
        recurrence_rule TEXT,
        location TEXT,
        latitude REAL,
        longitude REAL,
        is_completed INTEGER DEFAULT 0,
        category TEXT,
        priority INTEGER DEFAULT 3
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS notes (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT,
        category TEXT DEFAULT 'General',
        priority INTEGER DEFAULT 3,
        is_completed INTEGER DEFAULT 0,
        created_at TEXT,
        updated_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workflow_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workflow_id TEXT,
        success INTEGER,
        error_message TEXT,
        executed_at TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        display_name TEXT NOT NULL,
        package_name TEXT UNIQUE NOT NULL,
        nicknames TEXT,
        category TEXT DEFAULT 'Other',
        usage_pattern TEXT,
        last_used TEXT,
        is_favorite INTEGER DEFAULT 0,
        use_count INTEGER DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS long_term_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE NOT NULL,
        value TEXT NOT NULL,
        category TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        importance INTEGER DEFAULT 5
      )
    ''');
  }

  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    // Handle migrations here
  }

  Future<void> close() async {
    await _database?.close();
    _database = null;
  }
}
