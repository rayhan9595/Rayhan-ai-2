import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../datasources/local/sqlite_db.dart';

class MemoryRepository {
  static final MemoryRepository _instance = MemoryRepository._internal();
  factory MemoryRepository() => _instance;
  MemoryRepository._internal();

  Database? _db;

  Future<void> initialize() async {
    _db = await SQLiteDB().database;
  }

  Future<void> saveReminder(Map<String, dynamic> reminder) async {
    await _db?.insert(
      'reminders',
      reminder,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getPendingReminders() async {
    final now = DateTime.now().toIso8601String();
    return await _db?.query(
      'reminders',
      where: 'trigger_time <= ? AND is_completed = ?',
      whereArgs: [now, 0],
      orderBy: 'trigger_time ASC',
    ) ?? [];
  }

  Future<void> completeReminder(String id) async {
    await _db?.update(
      'reminders',
      {'is_completed': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> saveNote(Map<String, dynamic> note) async {
    await _db?.insert(
      'notes',
      note,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Map<String, dynamic>>> getNotes({String? category}) async {
    if (category != null) {
      return await _db?.query(
        'notes',
        where: 'category = ?',
        whereArgs: [category],
        orderBy: 'created_at DESC',
      ) ?? [];
    }
    return await _db?.query('notes', orderBy: 'created_at DESC') ?? [];
  }
}
