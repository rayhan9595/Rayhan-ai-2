import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../data/models/automation.dart';

class AutomationBuilderScreen extends StatefulWidget {
  const AutomationBuilderScreen({super.key});

  @override
  State<AutomationBuilderScreen> createState() => _AutomationBuilderScreenState();
}

class _AutomationBuilderScreenState extends State<AutomationBuilderScreen> {
  final _nameController = TextEditingController();
  String _triggerType = 'voice';
  final List<AutomationAction> _actions = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text('Automation Builder'),
        actions: [
          TextButton(
            onPressed: _saveAutomation,
            child: const Text('Save', style: TextStyle(color: AppTheme.primary)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _nameController,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                labelText: 'Automation Name',
                labelStyle: TextStyle(color: AppTheme.textSecondary),
              ),
            ),
            const SizedBox(height: 20),
            Text('Trigger Type', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                _buildTriggerChip('voice', 'Voice'),
                _buildTriggerChip('time', 'Time'),
                _buildTriggerChip('location', 'Location'),
              ],
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Actions', style: Theme.of(context).textTheme.titleLarge),
                IconButton(
                  icon: const Icon(Icons.add, color: AppTheme.primary),
                  onPressed: _addAction,
                ),
              ],
            ),
            ..._actions.asMap().entries.map((entry) => _buildActionTile(entry.key, entry.value)),
          ],
        ),
      ),
    );
  }

  Widget _buildTriggerChip(String value, String label) {
    final isSelected = _triggerType == value;

    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => setState(() => _triggerType = value),
      selectedColor: AppTheme.primary,
      labelStyle: TextStyle(
        color: isSelected ? Colors.black : AppTheme.textPrimary,
      ),
    );
  }

  Widget _buildActionTile(int index, AutomationAction action) {
    return ListTile(
      tileColor: AppTheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      leading: const Icon(Icons.flash_on, color: AppTheme.secondary),
      title: Text(action.type, style: const TextStyle(color: AppTheme.textPrimary)),
      subtitle: Text(
        action.params.toString(),
        style: const TextStyle(color: AppTheme.textSecondary),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: IconButton(
        icon: const Icon(Icons.delete, color: AppTheme.error),
        onPressed: () => setState(() => _actions.removeAt(index)),
      ),
    );
  }

  void _addAction() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.surface,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.mic, color: AppTheme.primary),
                title: const Text('Speak', style: TextStyle(color: AppTheme.textPrimary)),
                onTap: () {
                  _actions.add(AutomationAction(
                    type: 'speak',
                    params: {'text': 'Hello'},
                  ));
                  Navigator.pop(context);
                  setState(() {});
                },
              ),
              ListTile(
                leading: const Icon(Icons.notifications, color: AppTheme.secondary),
                title: const Text('Notification', style: TextStyle(color: AppTheme.textPrimary)),
                onTap: () {
                  _actions.add(AutomationAction(
                    type: 'notification',
                    params: {'title': 'Jarvis', 'body': 'Automation triggered'},
                  ));
                  Navigator.pop(context);
                  setState(() {});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveAutomation() {
    if (_nameController.text.isEmpty || _actions.isEmpty) return;
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }
}
