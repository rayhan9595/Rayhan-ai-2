import 'package:flutter/material.dart';
import '../../config/routes.dart';
import '../../config/theme.dart';
import '../../services/api_config_service.dart';
import '../../config/constants.dart';
import '../../core/ai_brain/nlp_processor.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _baseUrlController = TextEditingController();
  final TextEditingController _apiKeyController = TextEditingController();
  final TextEditingController _modelNameController = TextEditingController();

  final ApiConfigService _apiConfigService = ApiConfigService();
  final NLPProcessor _nlpProcessor = NLPProcessor();

  @override
  void initState() {
    super.initState();
    _loadApiConfig();
  }

  Future<void> _loadApiConfig() async {
    final config = await _apiConfigService.getApiConfig();
    setState(() {
      _baseUrlController.text = config?.baseUrl ?? Constants.defaultApiBaseUrl;
      _apiKeyController.text = config?.apiKey ?? Constants.defaultApiKey;
      _modelNameController.text = config?.modelName ?? Constants.defaultApiModelName;
    });
  }

  Future<void> _saveApiConfig() async {
    final newConfig = ApiConfig(
      baseUrl: _baseUrlController.text,
      apiKey: _apiKeyController.text,
      modelName: _modelNameController.text,
    );
    await _apiConfigService.saveApiConfig(newConfig);
    _nlpProcessor.updateApiConfig(newConfig); // Update NLPProcessor with new config
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('API settings saved successfully!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          _buildSectionHeader('API Configuration'),
          _buildTextField(
            controller: _baseUrlController,
            labelText: 'Base URL',
            hintText: 'e.g., https://api.openai.com/v1',
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: _apiKeyController,
            labelText: 'API Key',
            hintText: 'sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
            obscureText: true,
          ),
          const SizedBox(height: 12),
          _buildTextField(
            controller: _modelNameController,
            labelText: 'Model Name',
            hintText: 'e.g., gpt-3.5-turbo',
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _saveApiConfig,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text('Save API Settings', style: TextStyle(fontSize: 16)),
          ),

          const SizedBox(height: 30),
          _buildSectionHeader('General'),
          _buildTile(Icons.person, 'Profile', () {}),
          _buildTile(Icons.language, 'Language', () {}),
          _buildTile(Icons.dark_mode, 'Theme', () {}),

          _buildSectionHeader('Automation'),
          _buildTile(Icons.auto_mode, 'Automation Builder', () {
            Navigator.pushNamed(context, Routes.automationBuilder);
          }),
          _buildTile(Icons.workspaces, 'Workflow Editor', () {
            Navigator.pushNamed(context, Routes.workflowEditor);
          }),

          _buildSectionHeader('Data & Privacy'),
          _buildTile(Icons.memory, 'App Memory', () {
            Navigator.pushNamed(context, Routes.appMemory);
          }),
          _buildTile(Icons.analytics, 'Analytics', () {
            Navigator.pushNamed(context, Routes.analytics);
          }),

          _buildSectionHeader('Security'),
          _buildTile(Icons.security, 'Security Settings', () {}),
          _buildTile(Icons.fingerprint, 'Biometric Lock', () {}),

          _buildSectionHeader('About'),
          _buildTile(Icons.update, 'Check for Updates', () {}),
          _buildTile(Icons.bug_report, 'Report a Bug', () {}),

          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.delete_forever, color: AppTheme.error),
            title: const Text('Clear All Data', style: TextStyle(color: AppTheme.error)),
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 24, 0, 8),
      child: Text(
        title,
        style: const TextStyle(
          color: AppTheme.primary,
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildTile(IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.textSecondary),
      title: Text(title, style: const TextStyle(color: AppTheme.textPrimary)),
      trailing: const Icon(Icons.chevron_right, color: AppTheme.textSecondary),
      onTap: onTap,
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    String? hintText,
    bool obscureText = false,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      style: const TextStyle(color: AppTheme.textPrimary),
      decoration: InputDecoration(
        labelText: labelText,
        hintText: hintText,
        labelStyle: const TextStyle(color: AppTheme.textSecondary),
        hintStyle: const TextStyle(color: AppTheme.textSecondary),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: AppTheme.surface,
      ),
    );
  }

  @override
  void dispose() {
    _baseUrlController.dispose();
    _apiKeyController.dispose();
    _modelNameController.dispose();
    super.dispose();
  }
}
