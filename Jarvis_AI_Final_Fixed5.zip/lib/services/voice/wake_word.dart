import 'dart:async';

class WakeWordDetector {
  static final WakeWordDetector _instance = WakeWordDetector._internal();
  factory WakeWordDetector() => _instance;
  WakeWordDetector._internal();

  final _wakeWordController = StreamController<void>.broadcast();
  Stream<void> get onWakeWordDetected => _wakeWordController.stream;

  bool _isListening = false;
  Timer? _simulationTimer;

  Future<void> initialize() async {
    // In production, use Porcupine or similar
  }

  void startListening() {
    _isListening = true;
    _simulationTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      // This is just for simulation - replace with real wake word engine
    });
  }

  void simulateWakeWord() {
    _wakeWordController.add(null);
  }

  void stopListening() {
    _isListening = false;
    _simulationTimer?.cancel();
  }

  bool get isListening => _isListening;

  void dispose() {
    _wakeWordController.close();
    _simulationTimer?.cancel();
  }
}
