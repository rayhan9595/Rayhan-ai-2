import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../services/api_config_service.dart';
import '../../config/constants.dart';

class GeminiService {
  static final GeminiService _instance = GeminiService._internal();
  factory GeminiService() => _instance;
  GeminiService._internal();

  ApiConfig? _apiConfig;

  Future<void> initialize() async {
    _apiConfig = await ApiConfigService().getApiConfig();
  }

  Future<String> generateContent(String prompt) async {
    if (_apiConfig == null) await initialize();

    try {
      final url = Uri.parse('${Constants.defaultApiBaseUrl}/chat/completions');
      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${_apiConfig?.apiKey ?? Constants.defaultApiKey}',
      };
      final body = jsonEncode({
        'model': _apiConfig?.modelName ?? Constants.defaultApiModelName,
        'messages': [
          {'role': 'user', 'content': prompt},
        ],
      });

      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices']?[0]?['message']?['content'] ?? 'No response generated.';
      }
      return 'Error: ${response.statusCode}';
    } catch (e) {
      return 'Error: $e';
    }
  }

  Future<String> analyzeIntent(String text) async {
    final prompt = '''
    Analyze this command for a personal AI assistant.
    Command: "$text"
    Respond with just the intent name.
    ''';

    return await generateContent(prompt);
  }
}
