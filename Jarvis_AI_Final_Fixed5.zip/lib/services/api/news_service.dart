import '../../config/constants.dart';
import '../../data/datasources/remote/api_client.dart';

class NewsArticle {
  late final String title;
  late final String? description;
  late final String? url;
  late final String? imageUrl;
  late final DateTime? publishedAt;

  NewsArticle({
    required this.title,
    this.description,
    this.url,
    this.imageUrl,
    this.publishedAt,
  });

  Map<String, dynamic> toJson() => {
    'title': title,
    'description': description,
    'url': url,
    'image_url': imageUrl,
    'published_at': publishedAt?.toIso8601String(),
  };
}

class NewsService {
  static final NewsService _instance = NewsService._internal();
  factory NewsService() => _instance;
  NewsService._internal();

  final ApiClient _client = ApiClient();

  Future<List<NewsArticle>> getTopHeadlines({
    String category = 'general',
    int count = 5,
    String? query,
  }) async {
    final params = <String, dynamic>{
      'country': 'bd',
      'category': category,
      'pageSize': count,
      'apiKey': Constants.newsApiKey,
    };

    if (query != null) {
      params['q'] = query;
      params.remove('country');
      params.remove('category');
    }

    final response = await _client.get(
      'https://newsapi.org/v2/top-headlines',
      queryParams: params,
    );

    if (response.success && response.data != null) {
      final articles = response.data!['articles'] as List?;
      if (articles != null) {
        return articles.take(count).map((a) => NewsArticle(
          title: a['title'] ?? '',
          description: a['description'],
          url: a['url'],
          imageUrl: a['urlToImage'],
          publishedAt: a['publishedAt'] != null
            ? DateTime.tryParse(a['publishedAt'])
            : null,
        )).toList();
      }
    }

    return [];
  }
}
