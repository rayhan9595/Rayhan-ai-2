import '../../config/constants.dart';
import '../../data/datasources/remote/api_client.dart';

class WeatherData {
  late final double temperature;
  late final double feelsLike;
  late final int humidity;
  late final String description;
  late final double windSpeed;
  late final int rainProbability;
  late final String icon;

  WeatherData({
    required this.temperature,
    required this.feelsLike,
    required this.humidity,
    required this.description,
    required this.windSpeed,
    required this.rainProbability,
    required this.icon,
  });

  Map<String, dynamic> toJson() => {
    'temperature': temperature,
    'feels_like': feelsLike,
    'humidity': humidity,
    'description': description,
    'wind_speed': windSpeed,
    'rain_probability': rainProbability,
    'icon': icon,
  };
}

class WeatherService {
  static final WeatherService _instance = WeatherService._internal();
  factory WeatherService() => _instance;
  WeatherService._internal();

  final ApiClient _client = ApiClient();

  Future<WeatherData> getCurrentWeather([String? city]) async {
    final location = city ?? 'Dhaka';

    final response = await _client.get(
      'https://api.openweathermap.org/data/2.5/weather',
      queryParams: {
        'q': location,
        'appid': Constants.openWeatherApiKey,
        'units': 'metric',
        'lang': 'bn',
      },
    );

    if (response.success && response.data != null) {
      final data = response.data!;
      final main = data['main'];
      final weather = (data['weather'] as List).first;
      final wind = data['wind'];

      return WeatherData(
        temperature: (main['temp'] as num).toDouble(),
        feelsLike: (main['feels_like'] as num).toDouble(),
        humidity: main['humidity'] as int,
        description: weather['description'] as String,
        windSpeed: (wind['speed'] as num).toDouble(),
        rainProbability: data['clouds']['all'] as int,
        icon: weather['icon'] as String,
      );
    }

    return WeatherData(
      temperature: 30.0,
      feelsLike: 32.0,
      humidity: 70,
      description: 'Clear',
      windSpeed: 3.5,
      rainProbability: 20,
      icon: '02d',
    );
  }

  Future<double> getCurrentTemperature() async {
    final weather = await getCurrentWeather();
    return weather.temperature;
  }

  Future<int> getRainProbability() async {
    final weather = await getCurrentWeather();
    return weather.rainProbability;
  }
}
