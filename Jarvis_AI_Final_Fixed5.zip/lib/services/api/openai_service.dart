import '../../config/constants.dart';
import '../../data/datasources/remote/api_client.dart';

class OpenAIService {
  static final OpenAIService _instance = OpenAIService._internal();
  factory OpenAIService() => _instance;
  OpenAIService._internal();

  final ApiClient _client = ApiClient();

  Future<String> chatCompletion(String prompt, {String model = 'gpt-4'}) async {
    final response = await _client.post(
      'https://api.openai.com/v1/chat/completions',
      headers: {
        'Authorization': 'Bearer ${Constants.geminiApiKey}',
      },
      body: {
        'model': model,
        'messages': [
          {'role': 'system', 'content': 'You are Jarvis, a helpful Bengali-English bilingual AI assistant.'},
          {'role': 'user', 'content': prompt},
        ],
        'temperature': 0.7,
      },
    );

    if (response.success) {
      final choices = response.data?['choices'] as List?;
      if (choices != null && choices.isNotEmpty) {
        return choices.first['message']['content'] ?? '';
      }
    }

    return 'Sorry, I could not process that request.';
  }
}
