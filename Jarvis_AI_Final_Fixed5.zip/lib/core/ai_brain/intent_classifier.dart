import 'nlp_processor.dart';

class IntentClassifier {
  static final IntentClassifier _instance = IntentClassifier._internal();
  factory IntentClassifier() => _instance;
  IntentClassifier._internal();

  final NLPProcessor _nlp = NLPProcessor();

  Future<IntentResult> classify(String text, {List<Map<String, String>>? chatHistory}) async {
    final nlpResult = await _nlp.process(text, chatHistory: chatHistory);

    return IntentResult(
      primaryIntent: nlpResult.intent,
      confidence: nlpResult.confidence,
      entities: nlpResult.entities,
      requiresPermission: _requiresPermission(nlpResult.intent),
      canOffline: _canWorkOffline(nlpResult.intent),
    );
  }

  bool _requiresPermission(String intent) {
    final permissionIntents = [
      'call_contact', 'send_sms', 'open_app', 'control_device',
      'camera_capture', 'read_contacts', 'access_location',
    ];
    return permissionIntents.contains(intent);
  }

  bool _canWorkOffline(String intent) {
    final offlineIntents = [
      'open_app', 'set_alarm', 'set_reminder', 'take_note',
      'control_device', 'create_workflow',
    ];
    return offlineIntents.contains(intent);
  }
}

class IntentResult {
  late final String primaryIntent;
  late final double confidence;
  late final Map<String, dynamic> entities;
  late final bool requiresPermission;
  late final bool canOffline;

  IntentResult({
    required this.primaryIntent,
    required this.confidence,
    required this.entities,
    required this.requiresPermission,
    required this.canOffline,
  });
}
