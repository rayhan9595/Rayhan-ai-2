import 'dart:math';
import '../../config/constants.dart';
import '../../services/voice/tts_service.dart';

class ResponseGenerator {
  static final ResponseGenerator _instance = ResponseGenerator._internal();
  factory ResponseGenerator() => _instance;
  ResponseGenerator._internal();

  final TTSService _tts = TTSService();
  final Random _random = Random();
  String _lastResponse = '';

  String get lastResponse => _lastResponse;

  Future<void> generate({
    required String intent,
    required bool success,
    Map<String, dynamic>? data,
    String? customMessage,
  }) async {
    String response = '';

    if (customMessage != null) {
      response = customMessage;
    } else if (success) {
      response = _getSuccessResponse(intent, data);
    } else {
      response = _getErrorResponse(intent, data);
    }

    _lastResponse = response;
    await _tts.speak(response);
  }

  String _getSuccessResponse(String intent, Map<String, dynamic>? data) {
    final base = Constants.successReplies[_random.nextInt(Constants.successReplies.length)];

    switch (intent) {
      case 'open_app':
        return '${data?['app_name'] ?? 'App'} opened. $base';
      case 'set_alarm':
        return 'Alarm set for ${data?['time'] ?? 'the specified time'}.';
      case 'set_reminder':
        return 'Reminder set for ${data?['message'] ?? 'the specified time'}.';
      case 'call_contact':
        return 'Calling ${data?['contact'] ?? 'the contact'}...';
      case 'send_sms':
        return 'Message sent successfully.';
      case 'check_weather':
        return 'Weather information retrieved.';
      case 'read_news':
        return 'Here are the latest headlines.';
      case 'create_workflow':
        return 'Workflow created successfully.';
      default:
        return base;
    }
  }

  String _getErrorResponse(String intent, Map<String, dynamic>? data) {
    final base = Constants.errorReplies[_random.nextInt(Constants.errorReplies.length)];

    switch (intent) {
      case 'open_app':
        return 'Could not open the app. Please check if it is installed.';
      case 'set_alarm':
        return 'Failed to set alarm. Please try again.';
      case 'call_contact':
        return 'Unable to make the call. Please check permissions.';
      case 'permission_request':
        return 'Permission is required to proceed. Please grant access.';
      default:
        return base;
    }
  }

  String generateSelfUpdateConfirmation(String featureName) {
    return 'The new feature "$featureName" has been deployed successfully.';
  }

  String generatePermissionExplanation(String permissionType) {
    final explanations = {
      'camera': 'Camera access is needed for capturing images.',
      'location': 'Location access is needed for location-based automations.',
      'contacts': 'Contacts access is needed for SMS and calling features.',
      'phone': 'Phone access is needed for making calls.',
      'sms': 'SMS access is needed for sending messages.',
      'storage': 'Storage access is needed for file operations.',
      'microphone': 'Microphone access is needed for voice commands.',
    };
    return explanations[permissionType] ?? 'This permission is required for the requested operation.';
  }
}
