import 'dart:convert';
import 'self_analyzer.dart';

class GeneratedCode {
  late final String featureName;
  late final String code;
  late final String filePath;
  late final List<String> dependencies;
  late final String? testCode;

  GeneratedCode({
    required this.featureName,
    required this.code,
    required this.filePath,
    required this.dependencies,
    this.testCode,
  });
}

class SelfGenerator {
  static final SelfGenerator _instance = SelfGenerator._internal();
  factory SelfGenerator() => _instance;
  SelfGenerator._internal();

  Future<GeneratedCode> generate(NeedAnalysis analysis) async {
    switch (analysis.featureName) {
      case 'weekly_report':
        return _generateWeeklyReportFeature(analysis);
      case 'smart_scheduler':
        return _generateSmartScheduler(analysis);
      default:
        return _generateGenericFeature(analysis);
    }
  }

  GeneratedCode _generateWeeklyReportFeature(NeedAnalysis analysis) {
    final code = '''
{
  "feature": "weekly_report",
  "trigger": {
    "type": "time",
    "schedule": "0 9 * * 5",
    "timezone": "Asia/Dhaka"
  },
  "actions": [
    {
      "type": "analytics_collect",
      "params": {"period": "7d"}
    },
    {
      "type": "generate_report",
      "params": {"format": "summary", "sections": ["automation", "device", "productivity"]}
    },
    {
      "type": "notification",
      "params": {
        "title": "Weekly Report",
        "body": "Your weekly automation report is ready."
      }
    },
    {
      "type": "speak",
      "params": {"text": "Your weekly report is ready."}
    }
  ],
  "conditions": [],
  "version": "1.0"
}
''';

    return GeneratedCode(
      featureName: analysis.featureName,
      code: code,
      filePath: 'assets/workflows/weekly_report.json',
      dependencies: ['flutter_local_notifications', 'workmanager'],
      testCode: '''
test('weekly report workflow', () async {
  final workflow = Workflow.fromJson(json);
  expect(workflow.actions.length, 4);
  expect(workflow.trigger.type, 'time');
});
''',
    );
  }

  GeneratedCode _generateSmartScheduler(NeedAnalysis analysis) {
    final code = '''
{
  "feature": "smart_scheduler",
  "trigger": {"type": "voice", "keyword": "schedule"},
  "actions": [
    {"type": "conflict_check", "params": {}},
    {"type": "calendar_insert", "params": {}},
    {"type": "reminder_set", "params": {"before_minutes": 15}}
  ],
  "conditions": [],
  "version": "1.0"
}
''';

    return GeneratedCode(
      featureName: analysis.featureName,
      code: code,
      filePath: 'assets/workflows/smart_scheduler.json',
      dependencies: ['device_calendar'],
    );
  }

  GeneratedCode _generateGenericFeature(NeedAnalysis analysis) {
    return GeneratedCode(
      featureName: analysis.featureName,
      code: jsonEncode({
        'feature': analysis.featureName,
        'description': analysis.description,
        'actions': [],
        'version': '1.0',
      }),
      filePath: 'assets/workflows/${analysis.featureName}.json',
      dependencies: [],
    );
  }
}
