import 'dart:async';
import 'dart:isolate';
import 'dart:math';
import 'dart:convert';
import 'dart:io';
import '../../config/constants.dart';
import 'self_generator.dart';

class TestResult {
  late final bool passed;
  late final String testName;
  late final String? errorMessage;
  late final int executionTimeMs;
  late final double cpuUsagePercent;
  late final int memoryUsageMB;
  late final List<String> logs;

  TestResult({
    required this.passed,
    required this.testName,
    this.errorMessage,
    required this.executionTimeMs,
    required this.cpuUsagePercent,
    required this.memoryUsageMB,
    this.logs = const [],
  });
}

class SelfTester {
  static final SelfTester _instance = SelfTester._internal();
  factory SelfTester() => _instance;
  SelfTester._internal();

  Future<TestResult> runSandboxTest(GeneratedCode code) async {
    final stopwatch = Stopwatch()..start();
    final logs = <String>[];

    try {
      final result = await _runInIsolate(code.code);

      stopwatch.stop();
      final execTime = stopwatch.elapsedMilliseconds;

      final cpuUsage = _simulateCpuCheck();
      final memoryUsage = _simulateMemoryCheck();

      if (execTime > Constants.maxSandboxTimeMs) {
        return TestResult(
          passed: false,
          testName: code.featureName,
          errorMessage: 'Timeout: ${execTime}ms (Max: ${Constants.maxSandboxTimeMs}ms)',
          executionTimeMs: execTime,
          cpuUsagePercent: cpuUsage,
          memoryUsageMB: memoryUsage,
          logs: [...logs, 'TIMEOUT_ERROR'],
        );
      }

      if (cpuUsage > Constants.maxSandboxCpuPercent) {
        return TestResult(
          passed: false,
          testName: code.featureName,
          errorMessage: 'CPU Limit: ${cpuUsage.toStringAsFixed(1)}%',
          executionTimeMs: execTime,
          cpuUsagePercent: cpuUsage,
          memoryUsageMB: memoryUsage,
          logs: [...logs, 'CPU_LIMIT_EXCEEDED'],
        );
      }

      if (memoryUsage > Constants.maxSandboxRamMB) {
        return TestResult(
          passed: false,
          testName: code.featureName,
          errorMessage: 'Memory Limit: ${memoryUsage}MB',
          executionTimeMs: execTime,
          cpuUsagePercent: cpuUsage,
          memoryUsageMB: memoryUsage,
          logs: [...logs, 'MEMORY_LIMIT_EXCEEDED'],
        );
      }

      return TestResult(
        passed: result,
        testName: code.featureName,
        executionTimeMs: execTime,
        cpuUsagePercent: cpuUsage,
        memoryUsageMB: memoryUsage,
        logs: [...logs, 'TEST_PASSED'],
      );
    } catch (e) {
      stopwatch.stop();
      return TestResult(
        passed: false,
        testName: code.featureName,
        errorMessage: 'Crash: $e',
        executionTimeMs: stopwatch.elapsedMilliseconds,
        cpuUsagePercent: 0,
        memoryUsageMB: 0,
        logs: [...logs, 'CRASH: $e'],
      );
    }
  }

  Future<bool> _runInIsolate(String code) async {
    final receivePort = ReceivePort();

    await Isolate.spawn(
      _isolateEntry,
      [receivePort.sendPort, code],
    );

    final result = await receivePort.first as bool;
    return result;
  }

  static void _isolateEntry(List<dynamic> args) {
    final sendPort = args[0] as SendPort;
    final code = args[1] as String;

    try {
      final data = json.decode(code);

      final harmfulPatterns = [
        'while(true)', 'for(;;)', 'Runtime.exec', 'Process.start',
        'dart:io', 'File.delete', 'System.exit',
      ];

      final codeStr = code.toLowerCase();
      for (final pattern in harmfulPatterns) {
        if (codeStr.contains(pattern.toLowerCase())) {
          sendPort.send(false);
          return;
        }
      }

      sleep(const Duration(milliseconds: 100));

      sendPort.send(true);
    } catch (e) {
      sendPort.send(false);
    }
  }

  double _simulateCpuCheck() {
    return 10.0 + Random().nextDouble() * 15.0;
  }

  int _simulateMemoryCheck() {
    return 20 + Random().nextInt(40);
  }

  Future<List<TestResult>> runTestSuite(List<GeneratedCode> codes) async {
    final results = <TestResult>[];

    for (final code in codes) {
      final result = await runSandboxTest(code);
      results.add(result);

      if (!result.passed) {
        break;
      }
    }

    return results;
  }
}
