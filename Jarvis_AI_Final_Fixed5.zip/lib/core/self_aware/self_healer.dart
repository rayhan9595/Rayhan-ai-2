import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'self_generator.dart';
import 'self_tester.dart';
import 'self_deployer.dart';

class SelfHealer {
  static final SelfHealer _instance = SelfHealer._internal();
  factory SelfHealer() => _instance;
  SelfHealer._internal();

  final SelfGenerator _generator = SelfGenerator();
  final SelfTester _tester = SelfTester();
  final SelfDeployer _deployer = SelfDeployer();

  Future<bool> attemptFix(String featureName, String errorLog) async {
    final errorType = _classifyError(errorLog);
    final patch = await _generatePatch(featureName, errorType, errorLog);
    final testResult = await _tester.runSandboxTest(patch);

    if (testResult.passed) {
      final deployResult = await _deployer.deploy(patch, testResult);
      return deployResult.success;
    }

    return await _deployer.rollback(featureName);
  }

  ErrorType _classifyError(String errorLog) {
    final lower = errorLog.toLowerCase();

    if (lower.contains('null') || lower.contains('nullpointer')) {
      return ErrorType.nullReference;
    } else if (lower.contains('timeout') || lower.contains('deadline')) {
      return ErrorType.timeout;
    } else if (lower.contains('memory') || lower.contains('oom')) {
      return ErrorType.memoryLeak;
    } else if (lower.contains('permission') || lower.contains('denied')) {
      return ErrorType.permissionDenied;
    } else if (lower.contains('network') || lower.contains('socket')) {
      return ErrorType.networkError;
    } else {
      return ErrorType.unknown;
    }
  }

  Future<GeneratedCode> _generatePatch(
    String featureName,
    ErrorType errorType,
    String errorLog,
  ) async {
    final patchCode = '''
{
  "feature": "$featureName",
  "patch": true,
  "error_type": "${errorType.name}",
  "fallback_actions": [
    {"type": "notification", "params": {"title": "Error", "body": "An error occurred in $featureName"}},
    {"type": "speak", "params": {"text": "An error was detected and corrected."}}
  ],
  "version": "1.0.1-patch"
}
''';

    return GeneratedCode(
      featureName: '${featureName}_patch',
      code: patchCode,
      filePath: 'assets/workflows/${featureName}_patch.json',
      dependencies: [],
    );
  }

  Future<void> logError(String featureName, String error, String stackTrace) async {
    final prefs = await SharedPreferences.getInstance();
    final errors = prefs.getStringList('error_logs') ?? [];

    errors.add(jsonEncode({
      'feature': featureName,
      'error': error,
      'stackTrace': stackTrace,
      'timestamp': DateTime.now().toIso8601String(),
    }));

    await prefs.setStringList('error_logs', errors);
  }

  Future<List<Map<String, dynamic>>> getErrorLogs() async {
    final prefs = await SharedPreferences.getInstance();
    final errors = prefs.getStringList('error_logs') ?? [];

    return errors.map((e) => jsonDecode(e) as Map<String, dynamic>).toList();
  }
}

enum ErrorType {
  nullReference,
  timeout,
  memoryLeak,
  permissionDenied,
  networkError,
  unknown,
}
