import 'dart:convert';
import '../../services/voice/tts_service.dart';
import '../../services/device/phone_service.dart';
import '../../services/device/sms_service.dart';
import '../../services/device/system_service.dart';
import '../../services/device/app_launcher_service.dart';
import '../../services/api/weather_service.dart';
import '../../services/api/news_service.dart';
import '../../services/permission/permission_router.dart';
import '../../services/iot/smart_home.dart';
import '../../core/memory/app_memory.dart';
import '../../data/models/automation.dart';

class ActionResult {
  late final bool success;
  late final String message;
  late final Map<String, dynamic>? data;

  ActionResult({
    required this.success,
    required this.message,
    this.data,
  });
}

class ActionExecutor {
  static final ActionExecutor _instance = ActionExecutor._internal();
  factory ActionExecutor() => _instance;
  ActionExecutor._internal();

  final TTSService _tts = TTSService();
  final PhoneService _phone = PhoneService();
  final SMSService _sms = SMSService();
  final SystemService _system = SystemService();
  final AppLauncherService _appLauncher = AppLauncherService();
  final WeatherService _weather = WeatherService();
  final NewsService _news = NewsService();
  final PermissionRouter _permissionRouter = PermissionRouter();
  final SmartHomeService _smartHome = SmartHomeService();
  final AppMemory _appMemory = AppMemory();

  Future<ActionResult> execute(AutomationAction action) async {
    try {
      switch (action.type) {
        case 'speak':
          return await _executeSpeak(action.params);
        case 'call':
          return await _executeCall(action.params);
        case 'sms':
          return await _executeSMS(action.params);
        case 'open_app':
          return await _executeOpenApp(action.params);
        case 'system_setting':
          return await _executeSystemSetting(action.params);
        case 'weather_check':
          return await _executeWeatherCheck(action.params);
        case 'news_read':
          return await _executeNewsRead(action.params);
        case 'smart_home':
          return await _executeSmartHome(action.params);
        case 'notification':
          return await _executeNotification(action.params);
        case 'delay':
          return await _executeDelay(action.params);
        case 'launch_url':
          return await _executeLaunchUrl(action.params);
        default:
          return ActionResult(
            success: false,
            message: 'Unknown action type: ${action.type}',
          );
      }
    } catch (e) {
      return ActionResult(
        success: false,
        message: 'Execution error: $e',
      );
    }
  }

  Future<ActionResult> _executeSpeak(Map<String, dynamic> params) async {
    final text = params['text'] as String;
    await _tts.speak(text);
    return ActionResult(success: true, message: 'Spoken: $text');
  }

  Future<ActionResult> _executeCall(Map<String, dynamic> params) async {
    final number = params['number'] as String;
    final hasPermission = await _permissionRouter.checkAndRoute('phone');
    if (!hasPermission) {
      return ActionResult(
        success: false,
        message: 'No phone permission',
      );
    }
    await _phone.call(number);
    return ActionResult(success: true, message: 'Calling: $number');
  }

  Future<ActionResult> _executeSMS(Map<String, dynamic> params) async {
    final number = params['number'] as String;
    final message = params['message'] as String;
    final hasPermission = await _permissionRouter.checkAndRoute('sms');
    if (!hasPermission) {
      return ActionResult(
        success: false,
        message: 'No SMS permission',
      );
    }
    await _sms.sendSMS(number, message);
    return ActionResult(success: true, message: 'SMS sent');
  }

  Future<ActionResult> _executeOpenApp(Map<String, dynamic> params) async {
    final appName = params['app_name'] as String;
    final packageName = await _appMemory.getPackageName(appName);

    if (packageName != null) {
      final success = await _appLauncher.launchApp(packageName);
      return ActionResult(
        success: success,
        message: success ? '$appName launched' : '$appName launch failed',
      );
    }

    final found = await _appLauncher.findAndLaunchApp(appName);
    return ActionResult(
      success: found,
      message: found ? '$appName launched via search' : '$appName not found',
    );
  }

  Future<ActionResult> _executeSystemSetting(Map<String, dynamic> params) async {
    final setting = params['setting'] as String;
    final value = params['value'];

    switch (setting) {
      case 'wifi':
        await _system.setWifiEnabled(value == true);
        break;
      case 'bluetooth':
        await _system.setBluetoothEnabled(value == true);
        break;
      case 'brightness':
        await _system.setBrightness(value as double);
        break;
      case 'volume':
        await _system.setVolume(value as double);
        break;
      case 'airplane_mode':
        await _system.setAirplaneMode(value == true);
        break;
      case 'flashlight':
        await _system.setFlashlight(value == true);
        break;
      default:
        return ActionResult(success: false, message: 'Unknown setting');
    }

    return ActionResult(success: true, message: '$setting updated');
  }

  Future<ActionResult> _executeWeatherCheck(Map<String, dynamic> params) async {
    final location = params['location'] as String?;
    final weather = await _weather.getCurrentWeather(location);
    final summary = 'Weather: ${weather.description}, Temperature: ${weather.temperature} C';
    await _tts.speak(summary);
    return ActionResult(success: true, message: summary, data: weather.toJson());
  }

  Future<ActionResult> _executeNewsRead(Map<String, dynamic> params) async {
    final category = params['category'] as String? ?? 'general';
    final count = params['count'] as int? ?? 5;
    final news = await _news.getTopHeadlines(category: category, count: count);

    final buffer = StringBuffer();
    buffer.write('Top $count headlines:\n');
    for (var i = 0; i < news.length; i++) {
      buffer.write('${i + 1}. ${news[i].title}. ');
    }

    final text = buffer.toString();
    await _tts.speak(text);
    return ActionResult(success: true, message: text, data: {'articles': news.map((n) => n.toJson()).toList()});
  }

  Future<ActionResult> _executeSmartHome(Map<String, dynamic> params) async {
    final device = params['device'] as String;
    final command = params['command'] as String;
    final value = params['value'];

    await _smartHome.sendCommand(device, command, value);
    return ActionResult(
      success: true,
      message: '$device $command command sent',
    );
  }

  Future<ActionResult> _executeNotification(Map<String, dynamic> params) async {
    final title = params['title'] as String;
    final body = params['body'] as String;
    final payload = params['payload'] as String?;

    await _system.showNotification(title, body, payload: payload);
    return ActionResult(success: true, message: 'Notification shown');
  }

  Future<ActionResult> _executeDelay(Map<String, dynamic> params) async {
    final seconds = params['seconds'] as int? ?? 1;
    await Future.delayed(Duration(seconds: seconds));
    return ActionResult(success: true, message: 'Delayed for $seconds seconds');
  }

  Future<ActionResult> _executeLaunchUrl(Map<String, dynamic> params) async {
    final url = params['url'] as String;
    await _system.launchURL(url);
    return ActionResult(success: true, message: 'URL launched');
  }

  Future<List<ActionResult>> executeSequence(List<AutomationAction> actions) async {
    final results = <ActionResult>[];

    for (final action in actions) {
      final result = await execute(action);
      results.add(result);

      if (!result.success && action.stopOnFailure != false) {
        break;
      }
    }

    return results;
  }
}
