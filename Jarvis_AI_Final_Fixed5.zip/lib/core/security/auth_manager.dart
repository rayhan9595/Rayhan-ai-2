import 'dart:convert';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthManager {
  static final AuthManager _instance = AuthManager._internal();
  factory AuthManager() => _instance;
  AuthManager._internal();

  final LocalAuthentication _localAuth = LocalAuthentication();

  Future<bool> authenticate() async {
    final isAvailable = await _localAuth.canCheckBiometrics;
    if (!isAvailable) return true;

    return await _localAuth.authenticate(
      localizedReason: 'Jarvis authentication required',
      options: const AuthenticationOptions(
        stickyAuth: true,
        biometricOnly: false,
      ),
    );
  }

  Future<bool> isFirstLaunch() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('first_launch') ?? true;
  }

  Future<void> setFirstLaunchComplete() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('first_launch', false);
  }

  Future<void> setMasterPassword(String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('master_hash', password);
  }

  Future<bool> verifyMasterPassword(String password) async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString('master_hash');
    return stored == password;
  }

  Future<void> enableAutoLock(bool enable) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('auto_lock', enable);
  }

  Future<bool> isAutoLockEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('auto_lock') ?? true;
  }
}
