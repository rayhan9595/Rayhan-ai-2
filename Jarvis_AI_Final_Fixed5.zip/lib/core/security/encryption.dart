import 'dart:convert';
import 'dart:typed_data';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'package:crypto/crypto.dart';

class EncryptionService {
  static final EncryptionService _instance = EncryptionService._internal();
  factory EncryptionService() => _instance;
  EncryptionService._internal();

  late final encrypt.Key _key;
  late final encrypt.IV _iv;

  Future<void> initialize(String masterPassword) async {
    final keyBytes = sha256.convert(utf8.encode(masterPassword)).bytes;
    _key = encrypt.Key(Uint8List.fromList(keyBytes));
    _iv = encrypt.IV.fromLength(16);
  }

  String encryptData(String plainText) {
    final encrypter = encrypt.Encrypter(
      encrypt.AES(_key, mode: encrypt.AESMode.cbc),
    );
    final encrypted = encrypter.encrypt(plainText, iv: _iv);
    return '${base64Encode(_iv.bytes)}:${encrypted.base64}';
  }

  String decryptData(String cipherText) {
    final parts = cipherText.split(':');
    if (parts.length != 2) throw Exception('Invalid cipher format');

    final iv = encrypt.IV.fromBase64(parts[0]);
    final encrypted = encrypt.Encrypted.fromBase64(parts[1]);

    final encrypter = encrypt.Encrypter(
      encrypt.AES(_key, mode: encrypt.AESMode.cbc),
    );

    return encrypter.decrypt(encrypted, iv: iv);
  }

  String hashString(String input) {
    return sha256.convert(utf8.encode(input)).toString();
  }
}
