import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../../data/datasources/local/sqlite_db.dart';

class AppMemoryEntry {
  late final String displayName;
  late final String packageName;
  late final List<String> nicknames;
  late final String category;
  late final List<String> usagePattern;
  late final DateTime? lastUsed;
  late final bool isFavorite;
  late final int useCount;

  AppMemoryEntry({
    required this.displayName,
    required this.packageName,
    this.nicknames = const [],
    this.category = 'Other',
    this.usagePattern = const [],
    this.lastUsed,
    this.isFavorite = false,
    this.useCount = 0,
  });

  Map<String, dynamic> toJson() => {
    'display_name': displayName,
    'package_name': packageName,
    'nicknames': jsonEncode(nicknames),
    'category': category,
    'usage_pattern': jsonEncode(usagePattern),
    'last_used': lastUsed?.toIso8601String(),
    'is_favorite': isFavorite ? 1 : 0,
    'use_count': useCount,
  };

  static AppMemoryEntry fromJson(Map<String, dynamic> json) => AppMemoryEntry(
    displayName: json['display_name'],
    packageName: json['package_name'],
    nicknames: List<String>.from(jsonDecode(json['nicknames'])),
    category: json['category'],
    usagePattern: List<String>.from(jsonDecode(json['usage_pattern'])),
    lastUsed: json['last_used'] != null ? DateTime.parse(json['last_used']) : null,
    isFavorite: json['is_favorite'] == 1,
    useCount: json['use_count'],
  );
}

class AppMemory {
  static final AppMemory _instance = AppMemory._internal();
  factory AppMemory() => _instance;
  AppMemory._internal();

  Database? _db;
  final Map<String, String> _cache = {};

  Future<void> initialize() async {
    _db = await SQLiteDB().database;
    await _createTable();
    await _loadCache();
  }

  Future<void> _createTable() async {
    await _db?.execute('''
      CREATE TABLE IF NOT EXISTS app_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        display_name TEXT NOT NULL,
        package_name TEXT UNIQUE NOT NULL,
        nicknames TEXT,
        category TEXT DEFAULT 'Other',
        usage_pattern TEXT,
        last_used TEXT,
        is_favorite INTEGER DEFAULT 0,
        use_count INTEGER DEFAULT 0
      )
    ''');
  }

  Future<void> _loadCache() async {
    final results = await _db?.query('app_memory');
    if (results != null) {
      for (final row in results) {
        _cache[row['display_name'] as String] = row['package_name'] as String;
        final nicknames = List<String>.from(jsonDecode(row['nicknames'] as String? ?? '[]'));
        for (final nick in nicknames) {
          _cache[nick.toLowerCase()] = row['package_name'] as String;
        }
      }
    }
  }

  Future<void> saveApp({
    required String displayName,
    required String packageName,
    List<String> nicknames = const [],
    String category = 'Other',
  }) async {
    final entry = AppMemoryEntry(
      displayName: displayName,
      packageName: packageName,
      nicknames: [displayName.toLowerCase(), ...nicknames],
      category: category,
      lastUsed: DateTime.now(),
      useCount: 1,
    );

    await _db?.insert(
      'app_memory',
      entry.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );

    _cache[displayName.toLowerCase()] = packageName;
    for (final nick in nicknames) {
      _cache[nick.toLowerCase()] = packageName;
    }
  }

  Future<String?> getPackageName(String appName) async {
    final cached = _cache[appName.toLowerCase()];
    if (cached != null) return cached;

    final results = await _db?.query(
      'app_memory',
      where: 'display_name LIKE ? OR nicknames LIKE ?',
      whereArgs: ['%$appName%', '%$appName%'],
    );

    if (results != null && results.isNotEmpty) {
      final package = results.first['package_name'] as String;
      _cache[appName.toLowerCase()] = package;
      return package;
    }

    return null;
  }

  Future<List<AppMemoryEntry>> search(String query) async {
    final results = await _db?.query(
      'app_memory',
      where: 'display_name LIKE ? OR nicknames LIKE ? OR package_name LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'use_count DESC',
    );

    return results?.map((r) => AppMemoryEntry.fromJson(r)).toList() ?? [];
  }

  Future<void> recordUsage(String packageName) async {
    await _db?.rawUpdate('''
      UPDATE app_memory
      SET use_count = use_count + 1, last_used = ?
      WHERE package_name = ?
    ''', [DateTime.now().toIso8601String(), packageName]);
  }

  Future<List<AppMemoryEntry>> getFrequentlyUsed({int limit = 10}) async {
    final results = await _db?.query(
      'app_memory',
      orderBy: 'use_count DESC, last_used DESC',
      limit: limit,
    );

    return results?.map((r) => AppMemoryEntry.fromJson(r)).toList() ?? [];
  }

  Future<List<AppMemoryEntry>> getByCategory(String category) async {
    final results = await _db?.query(
      'app_memory',
      where: 'category = ?',
      whereArgs: [category],
      orderBy: 'use_count DESC',
    );

    return results?.map((r) => AppMemoryEntry.fromJson(r)).toList() ?? [];
  }

  Future<void> toggleFavorite(String packageName) async {
    await _db?.rawUpdate('''
      UPDATE app_memory
      SET is_favorite = CASE WHEN is_favorite = 1 THEN 0 ELSE 1 END
      WHERE package_name = ?
    ''', [packageName]);
  }

  Future<void> deleteApp(String packageName) async {
    await _db?.delete(
      'app_memory',
      where: 'package_name = ?',
      whereArgs: [packageName],
    );
    _cache.removeWhere((_, value) => value == packageName);
  }
}
