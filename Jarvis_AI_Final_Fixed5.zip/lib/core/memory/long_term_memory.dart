import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../../data/datasources/local/sqlite_db.dart';

class LTMEntry {
  late final String key;
  late final dynamic value;
  late final String category;
  late final DateTime createdAt;
  late final DateTime? updatedAt;
  late final int importance;

  LTMEntry({
    required this.key,
    required this.value,
    required this.category,
    DateTime? createdAt,
    this.updatedAt,
    this.importance = 5,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'key': key,
    'value': jsonEncode(value),
    'category': category,
    'created_at': createdAt.toIso8601String(),
    'updated_at': updatedAt?.toIso8601String(),
    'importance': importance,
  };

  static LTMEntry fromJson(Map<String, dynamic> json) => LTMEntry(
    key: json['key'],
    value: jsonDecode(json['value']),
    category: json['category'],
    createdAt: DateTime.parse(json['created_at']),
    updatedAt: json['updated_at'] != null ? DateTime.parse(json['updated_at']) : null,
    importance: json['importance'],
  );
}

class LongTermMemory {
  static final LongTermMemory _instance = LongTermMemory._internal();
  factory LongTermMemory() => _instance;
  LongTermMemory._internal();

  Database? _db;

  Future<void> initialize() async {
    _db = await SQLiteDB().database;
    await _createTable();
  }

  Future<void> _createTable() async {
    await _db?.execute('''
      CREATE TABLE IF NOT EXISTS long_term_memory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE NOT NULL,
        value TEXT NOT NULL,
        category TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT,
        importance INTEGER DEFAULT 5
      )
    ''');

    await _db?.execute('''
      CREATE INDEX IF NOT EXISTS idx_ltm_category ON long_term_memory(category)
    ''');
  }

  Future<void> store(String key, dynamic value, {
    String category = 'general',
    int importance = 5,
  }) async {
    final entry = LTMEntry(
      key: key,
      value: value,
      category: category,
      updatedAt: DateTime.now(),
      importance: importance,
    );

    await _db?.insert(
      'long_term_memory',
      entry.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<dynamic> retrieve(String key) async {
    final results = await _db?.query(
      'long_term_memory',
      where: 'key = ?',
      whereArgs: [key],
    );

    if (results == null || results.isEmpty) return null;
    return LTMEntry.fromJson(results.first).value;
  }

  Future<List<LTMEntry>> searchByCategory(String category) async {
    final results = await _db?.query(
      'long_term_memory',
      where: 'category = ?',
      whereArgs: [category],
      orderBy: 'importance DESC, updated_at DESC',
    );

    return results?.map((r) => LTMEntry.fromJson(r)).toList() ?? [];
  }

  Future<List<LTMEntry>> search(String query) async {
    final results = await _db?.query(
      'long_term_memory',
      where: 'key LIKE ? OR value LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
    );

    return results?.map((r) => LTMEntry.fromJson(r)).toList() ?? [];
  }

  Future<void> delete(String key) async {
    await _db?.delete(
      'long_term_memory',
      where: 'key = ?',
      whereArgs: [key],
    );
  }

  Future<void> updateImportance(String key, int importance) async {
    await _db?.update(
      'long_term_memory',
      {'importance': importance, 'updated_at': DateTime.now().toIso8601String()},
      where: 'key = ?',
      whereArgs: [key],
    );
  }
}
