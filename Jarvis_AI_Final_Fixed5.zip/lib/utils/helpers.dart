import 'package:intl/intl.dart';

class Helpers {
  static String formatDateTime(DateTime dt, {String locale = 'bn'}) {
    final formatter = DateFormat('dd MMM, yyyy - hh:mm a', locale);
    return formatter.format(dt);
  }

  static String formatDuration(Duration duration) {
    if (duration.inDays > 0) {
      return '${duration.inDays} days';
    } else if (duration.inHours > 0) {
      return '${duration.inHours} hours';
    } else if (duration.inMinutes > 0) {
      return '${duration.inMinutes} minutes';
    } else {
      return '${duration.inSeconds} seconds';
    }
  }

  static String truncate(String text, int maxLength) {
    if (text.length <= maxLength) return text;
    return '${text.substring(0, maxLength)}...';
  }

  static bool isBangaliText(String text) {
    final banglaRange = RegExp(r'[\u0980-\u09FF]');
    return banglaRange.hasMatch(text);
  }
}
