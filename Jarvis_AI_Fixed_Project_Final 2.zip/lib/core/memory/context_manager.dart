import 'short_term_memory.dart';
import 'long_term_memory.dart';

class ContextSnapshot {
  final Map<String, dynamic> sessionContext;
  final Map<String, dynamic> userProfile;
  final List<String> recentCommands;
  final String? currentLocation;
  final DateTime timestamp;

  ContextSnapshot({
    required this.sessionContext,
    required this.userProfile,
    required this.recentCommands,
    this.currentLocation,
    required this.timestamp,
  });
}

class ContextManager {
  static final ContextManager _instance = ContextManager._internal();
  factory ContextManager() => _instance;
  ContextManager._internal();

  final ShortTermMemory _stm = ShortTermMemory();
  final LongTermMemory _ltm = LongTermMemory();

  Future<void> initialize() async {
    _stm.initialize();
    await _ltm.initialize();
  }

  void setSessionContext(String key, dynamic value) {
    _stm.store(key, value);
  }

  dynamic getSessionContext(String key) {
    return _stm.retrieve(key);
  }

  Future<void> setUserProfile(String key, dynamic value) async {
    await _ltm.store(key, value, category: 'user_profile', importance: 9);
  }

  Future<dynamic> getUserProfile(String key) async {
    return await _ltm.retrieve(key);
  }

  void addCommandToHistory(String command) {
    final history = _stm.retrieve('command_history') as List<String>? ?? [];
    history.add(command);
    if (history.length > 20) history.removeAt(0);
    _stm.store('command_history', history);
  }

  List<String> getCommandHistory() {
    return (_stm.retrieve('command_history') as List<String>?) ?? [];
  }

  Future<ContextSnapshot> getFullContext() async {
    final userProfile = <String, dynamic>{};
    final profileEntries = await _ltm.searchByCategory('user_profile');
    for (final entry in profileEntries) {
      userProfile[entry.key] = entry.value;
    }

    return ContextSnapshot(
      sessionContext: _stm.getContext(),
      userProfile: userProfile,
      recentCommands: getCommandHistory(),
      currentLocation: _stm.retrieve('current_location'),
      timestamp: DateTime.now(),
    );
  }

  Future<void> clearSession() async {
    _stm.clear();
  }
}
