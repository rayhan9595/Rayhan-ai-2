import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/usecases/voice_command.dart';

abstract class VoiceEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class StartListeningEvent extends VoiceEvent {}
class StopListeningEvent extends VoiceEvent {}
class ProcessVoiceEvent extends VoiceEvent {
  final String text;
  ProcessVoiceEvent(this.text);
  @override
  List<Object?> get props => [text];
}

abstract class VoiceState extends Equatable {
  @override
  List<Object?> get props => [];
}

class VoiceInitial extends VoiceState {}
class VoiceListening extends VoiceState {}
class VoiceProcessing extends VoiceState {}
class VoiceSuccess extends VoiceState {
  final String message;
  VoiceSuccess(this.message);
  @override
  List<Object?> get props => [message];
}

class VoiceError extends VoiceState {
  final String message;
  VoiceError(this.message);
  @override
  List<Object?> get props => [message];
}

class VoiceBloc extends Bloc<VoiceEvent, VoiceState> {
  final VoiceCommandUseCase _useCase = VoiceCommandUseCase();

  VoiceBloc() : super(VoiceInitial()) {
    on<StartListeningEvent>(_onStart);
    on<StopListeningEvent>(_onStop);
    on<ProcessVoiceEvent>(_onProcess);
  }

  Future<void> _onStart(StartListeningEvent event, Emitter<VoiceState> emit) async {
    emit(VoiceListening());
    // Start STT and wait for result
    // Then add ProcessVoiceEvent
  }

  Future<void> _onStop(StopListeningEvent event, Emitter<VoiceState> emit) async {
    emit(VoiceInitial());
  }

  Future<void> _onProcess(ProcessVoiceEvent event, Emitter<VoiceState> emit) async {
    emit(VoiceProcessing());
    try {
      final result = await _useCase.execute(event.text);
      emit(result.success
        ? VoiceSuccess(result.message)
        : VoiceError(result.message));
    } catch (e) {
      emit(VoiceError(e.toString()));
    }
  }
}
