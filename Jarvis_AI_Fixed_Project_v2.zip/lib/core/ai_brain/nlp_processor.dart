import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../services/api_config_service.dart';
import '../../config/constants.dart';

class NLPResult {
  late final String intent;
  late final Map<String, dynamic> entities;
  late final String processedText;
  late final double confidence;

  NLPResult({
    required this.intent,
    required this.entities,
    required this.processedText,
    this.confidence = 0.9,
  });
}

class NLPProcessor {
  static final NLPProcessor _instance = NLPProcessor._internal();
  factory NLPProcessor() => _instance;
  NLPProcessor._internal();

  ApiConfig? _apiConfig;

  Future<void> initialize() async {
    _apiConfig = await ApiConfigService().getApiConfig();
    _apiConfig ??= ApiConfig(
      baseUrl: Constants.defaultApiBaseUrl,
      apiKey: Constants.defaultApiKey,
      modelName: Constants.defaultApiModelName,
    );
  }

  void updateApiConfig(ApiConfig newConfig) {
    _apiConfig = newConfig;
  }

  Future<NLPResult> process(String text, {String language = 'bn', List<Map<String, String>>? chatHistory}) async {
    final prompt = '''
    Analyze this Bengali/English mixed command for a personal AI assistant.
    Extract intent and entities. Respond ONLY in JSON format.

    Command: "$text"

    Possible intents: open_app, set_alarm, set_reminder, call_contact, send_sms,
    check_weather, read_news, control_device, create_workflow, search_web,
    translate, take_note, schedule_event, self_update, permission_request, unknown

    JSON format:
    {
      "intent": "intent_name",
      "entities": {
        "app_name": "string or null",
        "time": "ISO string or null",
        "date": "ISO string or null",
        "contact": "string or null",
        "message": "string or null",
        "location": "string or null",
        "query": "string or null",
        "language": "string or null",
        "device": "string or null",
        "action": "string or null"
      },
      "processed_text": "normalized command"
    }
    ''';

    try {
      if (_apiConfig == null || _apiConfig!.apiKey.isEmpty) {
        throw Exception('API configuration not set or API key is empty.');
      }

      final url = Uri.parse('${_apiConfig!.baseUrl}/chat/completions');
      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${_apiConfig!.apiKey}',
      };
      final body = jsonEncode({
        'model': _apiConfig!.modelName,
        'messages': [
          if (chatHistory != null) ...chatHistory,
          {'role': 'system', 'content': 'You are a helpful AI assistant that analyzes commands and extracts intents and entities in JSON format.'},
          {'role': 'user', 'content': prompt}
        ],
        'temperature': 0.1,
      });

      final httpResponse = await http.post(url, headers: headers, body: body);

      if (httpResponse.statusCode != 200) {
        throw Exception('API request failed with status ${httpResponse.statusCode}: ${httpResponse.body}');
      }

      final responseBody = jsonDecode(httpResponse.body);
      final jsonStr = responseBody['choices'][0]['message']['content'] ?? '{}';

      // Extract JSON from response
      final jsonStart = jsonStr.indexOf('{');
      final jsonEnd = jsonStr.lastIndexOf('}');
      if (jsonStart == -1 || jsonEnd == -1) {
        return _fallbackParse(text);
      }

      final cleanJson = jsonStr.substring(jsonStart, jsonEnd + 1);
      final data = json.decode(cleanJson) as Map<String, dynamic>;

      return NLPResult(
        intent: data['intent'] ?? 'unknown',
        entities: Map<String, dynamic>.from(data['entities'] ?? {}),
        processedText: data['processed_text'] ?? text,
        confidence: 0.92,
      );
    } catch (e) {
      print('NLP Processing Error: $e');
      return _fallbackParse(text);
    }
  }

  NLPResult _fallbackParse(String text) {
    final lower = text.toLowerCase();
    String intent = 'unknown';
    final entities = <String, dynamic>{};

    if (lower.contains('open')) {
      intent = 'open_app';
      entities['app_name'] = _extractAppName(text);
    } else if (lower.contains('alarm')) {
      intent = 'set_alarm';
      entities['time'] = _extractTime(text);
    } else if (lower.contains('remind')) {
      intent = 'set_reminder';
      entities['time'] = _extractTime(text);
      entities['message'] = text;
    } else if (lower.contains('call')) {
      intent = 'call_contact';
      entities['contact'] = _extractContact(text);
    } else if (lower.contains('sms') || lower.contains('message')) {
      intent = 'send_sms';
    } else if (lower.contains('weather')) {
      intent = 'check_weather';
    } else if (lower.contains('news')) {
      intent = 'read_news';
    }

    return NLPResult(
      intent: intent,
      entities: entities,
      processedText: text,
      confidence: 0.7,
    );
  }

  String? _extractAppName(String text) {
    final patterns = [
      RegExp(r'open\s+(\w+)'),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(text);
      if (match != null) return match.group(1);
    }
    return null;
  }

  String? _extractTime(String text) {
    final patterns = [
      RegExp(r'(\d{1,2}):(\d{2})'),
      RegExp(r'(\d{1,2})\s*(am|pm)'),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(text);
      if (match != null) return '${match.group(1)}:${match.group(2) ?? '00'}';
    }
    return null;
  }

  String? _extractContact(String text) {
    final pattern = RegExp(r'call\s+([\w\s]+)');
    final match = pattern.firstMatch(text);
    return match?.group(1)?.trim();
  }
}
