import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ApiResponse<T> {
  final bool success;
  final T? data;
  final String? error;
  final int statusCode;

  ApiResponse({
    required this.success,
    this.data,
    this.error,
    required this.statusCode,

class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  factory ApiClient() => _instance;
  ApiClient._internal();

  final Map<String, String> _defaultHeaders = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',

  Future<<ApiResponse<Map<String, dynamic>>> get(
    String url, {
    Map<String, String>? headers,
    Map<String, dynamic>? queryParams,
  }) async {
    try {
      var uri = Uri.parse(url);
      if (queryParams != null) {
        uri = uri.replace(queryParameters: queryParams.map(
          (k, v) => MapEntry(k, v.toString()),

      final response = await http.get(
        uri,
        headers: {..._defaultHeaders, ...?headers},
      ).timeout(const Duration(seconds: 30));

      return _handleResponse(response);
    } on SocketException {
      return ApiResponse(
        success: false,
        error: '  ',
        statusCode: 0,
    } catch (e) {
      return ApiResponse(
        success: false,
        error: e.toString(),
        statusCode: -1,

  Future<<ApiResponse<Map<String, dynamic>>> post(
    String url, {
    Map<String, String>? headers,
    Map<String, dynamic>? body,
  }) async {
    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {..._defaultHeaders, ...?headers},
        body: body != null ? jsonEncode(body) : null,
      ).timeout(const Duration(seconds: 30));

      return _handleResponse(response);
    } on SocketException {
      return ApiResponse(
        success: false,
        error: '  ',
        statusCode: 0,
    } catch (e) {
      return ApiResponse(
        success: false,
        error: e.toString(),
        statusCode: -1,

  ApiResponse<Map<String, dynamic>> _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      try {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        return ApiResponse(success: true, data: data, statusCode: response.statusCode);
      } catch (e) {
        return ApiResponse(
          success: true,
          data: {'raw': response.body},
          statusCode: response.statusCode,
    } else {
      return ApiResponse(
        success: false,
        error: 'API Error ${response.statusCode}: ${response.body}',
        statusCode: response.statusCode,