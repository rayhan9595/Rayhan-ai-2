import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import '../../core/ai_brain/response_generator.dart';
import 'permission_checker.dart';
import 'permission_memory.dart';

class PermissionRouter {
  static final PermissionRouter _instance = PermissionRouter._internal();
  factory PermissionRouter() => _instance;
  PermissionRouter._internal();

  final PermissionChecker _checker = PermissionChecker();
  final PermissionMemory _memory = PermissionMemory();
  final ResponseGenerator _response = ResponseGenerator();

  Future<bool> checkAndRoute(String permissionType, {BuildContext? context}) async {
    final memoryState = await _memory.getPermissionState(permissionType);
    if (memoryState == 'denied_permanently') {
      return false;
    }

    final granted = await _checker.check(permissionType);
    if (granted) return true;

    if (context != null) {
      final explanation = _response.generatePermissionExplanation(permissionType);
    }

    final requested = await _checker.request(permissionType);
    if (requested) {
      await _memory.savePermissionState(permissionType, 'granted');
      return true;
    }

    await _memory.savePermissionState(permissionType, 'denied_permanently');

    if (context != null) {
      // Show settings dialog
    }

    await openAppSettings();
    return false;
  }

  Future<void> openSettings() async {
    await AppSettings.openAppSettings();
  }
}
