class Automation {
  late final String id;
  late final String name;
  late final String description;
  late final String triggerType;
  late final Map<String, dynamic> triggerConfig;
  late final List<Map<String, dynamic> conditions;
  late final List<AutomationAction> actions;
  late final bool isActive;
  late final DateTime createdAt;
  late final DateTime? lastRun;
  late final int runCount;
  late final bool voiceConfirmation;

  Automation({
    required this.id,
    required this.name,
    this.description = '',
    required this.triggerType,
    required this.triggerConfig,
    this.conditions = const [],
    required this.actions,
    this.isActive = true,
    DateTime? createdAt,
    this.lastRun,
    this.runCount = 0,
    this.voiceConfirmation = true,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'description': description,
    'trigger_type': triggerType,
    'trigger_config': triggerConfig,
    'conditions': conditions,
    'actions': actions.map((a) => a.toJson()).toList(),
    'is_active': isActive ? 1 : 0,
    'created_at': createdAt.toIso8601String(),
    'last_run': lastRun?.toIso8601String(),
    'run_count': runCount,
    'voice_confirmation': voiceConfirmation ? 1 : 0,

  factory Automation.fromJson(Map<String, dynamic> json) => Automation(
    id: json['id'],
    name: json['name'],
    description: json['description'] ?? '',
    triggerType: json['trigger_type'],
    triggerConfig: json['trigger_config'] ?? {},
    conditions: List<Map<String, dynamic>.from(json['conditions'] ?? []),
    actions: (json['actions'] as List).map((a) => AutomationAction.fromJson(a)).toList(),
    isActive: json['is_active'] == 1,
    createdAt: DateTime.parse(json['created_at']),
    lastRun: json['last_run'] != null ? DateTime.parse(json['last_run']) : null,
    runCount: json['run_count'] ?? 0,
    voiceConfirmation: json['voice_confirmation'] == 1,

class AutomationAction {
  late final String type;
  late final Map<String, dynamic> params;
  late final bool stopOnFailure;
  late final int? delayMs;

  AutomationAction({
    required this.type,
    required this.params,
    this.stopOnFailure = true,
    this.delayMs,

  Map<String, dynamic> toJson() => {
    'type': type,
    'params': params,
    'stop_on_failure': stopOnFailure,
    'delay_ms': delayMs,

  factory AutomationAction.fromJson(Map<String, dynamic> json) => AutomationAction(
    type: json['type'],
    params: json['params'] ?? {},
    stopOnFailure: json['stop_on_failure'] ?? true,
    delayMs: json['delay_ms'],
}}}}}