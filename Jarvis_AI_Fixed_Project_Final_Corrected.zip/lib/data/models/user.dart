class User {
  late final String id;
  late final String name;
  late final String? email;
  late final String? phone;
  late final String preferredLanguage;
  late final String? address;
  late final Map<String, dynamic> preferences;
  late final DateTime createdAt;
  late final DateTime? lastActive;

  User({
    required this.id,
    required this.name,
    this.email,
    this.phone,
    this.preferredLanguage = 'bn',
    this.address,
    this.preferences = const {},
    DateTime? createdAt,
    this.lastActive,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'email': email,
    'phone': phone,
    'preferred_language': preferredLanguage,
    'address': address,
    'preferences': preferences,
    'created_at': createdAt.toIso8601String(),
    'last_active': lastActive?.toIso8601String(),

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json['id'],
    name: json['name'],
    email: json['email'],
    phone: json['phone'],
    preferredLanguage: json['preferred_language'] ?? 'bn',
    address: json['address'],
    preferences: json['preferences'] ?? {},
    createdAt: DateTime.parse(json['created_at']),
    lastActive: json['last_active'] != null ? DateTime.parse(json['last_active']) : null,
}}