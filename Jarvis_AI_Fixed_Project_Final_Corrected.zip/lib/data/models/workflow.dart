import 'automation.dart';

class Workflow {
  late final String id;
  late final String name;
  late final String triggerType;
  late final String triggerKeyword;
  late final List<Map<String, dynamic> conditions;
  late final String conditionLogic;
  late final List<AutomationAction> actions;
  late final bool isActive;
  late final DateTime? nextRunTime;
  late final double? latitude;
  late final double? longitude;
  late final double? radius;
  late final bool voiceConfirmation;

  Workflow({
    required this.id,
    required this.name,
    required this.triggerType,
    this.triggerKeyword = '',
    this.conditions = const [],
    this.conditionLogic = 'AND',
    required this.actions,
    this.isActive = true,
    this.nextRunTime,
    this.latitude,
    this.longitude,
    this.radius,
    this.voiceConfirmation = true,

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'trigger_type': triggerType,
    'trigger_keyword': triggerKeyword,
    'conditions': conditions,
    'condition_logic': conditionLogic,
    'actions': actions.map((a) => a.toJson()).toList(),
    'is_active': isActive ? 1 : 0,
    'next_run_time': nextRunTime?.toIso8601String(),
    'latitude': latitude,
    'longitude': longitude,
    'radius': radius,
    'voice_confirmation': voiceConfirmation ? 1 : 0,

  factory Workflow.fromJson(Map<String, dynamic> json) => Workflow(
    id: json['id'],
    name: json['name'],
    triggerType: json['trigger_type'],
    triggerKeyword: json['trigger_keyword'] ?? '',
    conditions: List<Map<String, dynamic>.from(json['conditions'] ?? []),
    conditionLogic: json['condition_logic'] ?? 'AND',
    actions: (json['actions'] as List).map((a) => AutomationAction.fromJson(a)).toList(),
    isActive: json['is_active'] == 1,
    nextRunTime: json['next_run_time'] != null ? DateTime.parse(json['next_run_time']) : null,
    latitude: json['latitude'],
    longitude: json['longitude'],
    radius: json['radius'],
    voiceConfirmation: json['voice_confirmation'] == 1,
}}}