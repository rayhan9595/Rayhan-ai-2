class AppMemoryModel {
  late final String displayName;
  late final String packageName;
  late final List<String> nicknames;
  late final String category;
  late final List<String> usagePattern;
  late final DateTime? lastUsed;
  late final bool isFavorite;
  late final int useCount;

  AppMemoryModel({
    required this.displayName,
    required this.packageName,
    this.nicknames = const [],
    this.category = 'Other',
    this.usagePattern = const [],
    this.lastUsed,
    this.isFavorite = false,
    this.useCount = 0,

  Map<String, dynamic> toJson() => {
    'display_name': displayName,
    'package_name': packageName,
    'nicknames': nicknames,
    'category': category,
    'usage_pattern': usagePattern,
    'last_used': lastUsed?.toIso8601String(),
    'is_favorite': isFavorite,
    'use_count': useCount,

  factory AppMemoryModel.fromJson(Map<String, dynamic> json) => AppMemoryModel(
    displayName: json['display_name'],
    packageName: json['package_name'],
    nicknames: List<String>.from(json['nicknames'] ?? []),
    category: json['category'] ?? 'Other',
    usagePattern: List<String>.from(json['usage_pattern'] ?? []),
    lastUsed: json['last_used'] != null ? DateTime.parse(json['last_used']) : null,
    isFavorite: json['is_favorite'] ?? false,
    useCount: json['use_count'] ?? 0,
}}}