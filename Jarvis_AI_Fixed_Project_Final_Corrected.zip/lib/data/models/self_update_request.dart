class SelfUpdateRequest {
  late final String id;
  late final String userRequest;
  late final String status; // pending, analyzing, generating, testing, deploying, completed, failed
  late final DateTime createdAt;
  late final DateTime? completedAt;
  late final String? generatedCode;
  late final String? testResult;
  late final String? errorLog;

  SelfUpdateRequest({
    required this.id,
    required this.userRequest,
    this.status = 'pending',
    DateTime? createdAt,
    this.completedAt,
    this.generatedCode,
    this.testResult,
    this.errorLog,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'user_request': userRequest,
    'status': status,
    'created_at': createdAt.toIso8601String(),
    'completed_at': completedAt?.toIso8601String(),
    'generated_code': generatedCode,
    'test_result': testResult,
    'error_log': errorLog,

  factory SelfUpdateRequest.fromJson(Map<String, dynamic> json) => SelfUpdateRequest(
    id: json['id'],
    userRequest: json['user_request'],
    status: json['status'],
    createdAt: DateTime.parse(json['created_at']),
    completedAt: json['completed_at'] != null ? DateTime.parse(json['completed_at']) : null,
    generatedCode: json['generated_code'],
    testResult: json['test_result'],
    errorLog: json['error_log'],
}}