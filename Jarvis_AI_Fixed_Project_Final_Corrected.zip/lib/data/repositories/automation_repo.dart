import 'package:sqflite/sqflite.dart';
import '../models/automation.dart';
import '../datasources/local/sqlite_db.dart';

class AutomationRepository {
  static final AutomationRepository _instance = AutomationRepository._internal();
  factory AutomationRepository() => _instance;
  AutomationRepository._internal();

  Database? _db;

  Future<void> initialize() async {
    _db = await SQLiteDB().database;
    await _createTable();

  Future<void> _createTable() async {
    await _db?.execute('''
      CREATE TABLE IF NOT EXISTS automations (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        trigger_type TEXT NOT NULL,
        trigger_config TEXT,
        conditions TEXT,
        actions TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT,
        last_run TEXT,
        run_count INTEGER DEFAULT 0,
        voice_confirmation INTEGER DEFAULT 1

  Future<void> insert(Automation automation) async {
    await _db?.insert(
      'automations',
      automation.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,

  Future<List<Automation> getAll() async {
    final results = await _db?.query('automations', orderBy: 'created_at DESC');
    return results?.map((r) => Automation.fromJson(r)).toList() ?? [];

  Future<List<Automation> getActive() async {
    final results = await _db?.query(
      'automations',
      where: 'is_active = ?',
      whereArgs: [1],
    return results?.map((r) => Automation.fromJson(r)).toList() ?? [];

  Future<Automation?> getById(String id) async {
    final results = await _db?.query(
      'automations',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    if (results == null || results.isEmpty) return null;
    return Automation.fromJson(results.first);

  Future<void> updateRun(String id) async {
    await _db?.rawUpdate('''
      UPDATE automations
      SET last_run = ?, run_count = run_count + 1
      WHERE id = ?
    ''', [DateTime.now().toIso8601String(), id]);

  Future<void> toggleActive(String id, bool active) async {
    await _db?.update(
      'automations',
      {'is_active': active ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],

  Future<void> delete(String id) async {
    await _db?.delete(
      'automations',
      where: 'id = ?',
      whereArgs: [id],
}}}}}}}}}}