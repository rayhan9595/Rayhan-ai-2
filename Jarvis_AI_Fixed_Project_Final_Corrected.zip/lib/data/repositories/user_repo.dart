import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';

class UserRepository {
  static final UserRepository _instance = UserRepository._internal();
  factory UserRepository() => _instance;
  UserRepository._internal();

  User? _cachedUser;

  Future<void> saveUser(User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user', jsonEncode(user.toJson()));
    _cachedUser = user;

  Future<User?> getCurrentUser() async {
    if (_cachedUser != null) return _cachedUser;

    final prefs = await SharedPreferences.getInstance();
    final userStr = prefs.getString('current_user');
    if (userStr == null) return null;

    _cachedUser = User.fromJson(jsonDecode(userStr));
    return _cachedUser;

  Future<void> updatePreferences(Map<String, dynamic> prefs) async {
    final user = await getCurrentUser();
    if (user != null) {
      final updated = User(
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        preferredLanguage: user.preferredLanguage,
        address: user.address,
        preferences: {...user.preferences, ...prefs},
        createdAt: user.createdAt,
        lastActive: DateTime.now(),
      await saveUser(updated);

  Future<void> clearUser() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('current_user');
    _cachedUser = null;
}}}}}}