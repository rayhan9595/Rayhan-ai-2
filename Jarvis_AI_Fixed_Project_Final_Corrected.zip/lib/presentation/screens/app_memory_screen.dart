import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../core/memory/app_memory.dart';

class AppMemoryScreen extends StatefulWidget {
  const AppMemoryScreen({super.key});

  @override
  State<AppMemoryScreen> createState() => _AppMemoryScreenState();

class _AppMemoryScreenState extends State<AppMemoryScreen> {
  final AppMemory _appMemory = AppMemory();
  List<AppMemoryEntry> _apps = [];
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadApps();

  Future<void> _loadApps() async {
    final apps = await _appMemory.getFrequentlyUsed(limit: 50);
    setState(() => _apps = apps);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        title: const Text(' '),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _showAddAppDialog,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: InputDecoration(
                hintText: ' ...',
                prefixIcon: const Icon(Icons.search, color: AppTheme.textSecondary),
                suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear, color: AppTheme.textSecondary),
                      onPressed: () {
                        _searchController.clear();
                        _loadApps();
                  : null,
              onChanged: (value) => _searchApps(value),
          Expanded(
            child: ListView.builder(
              itemCount: _apps.length,
              itemBuilder: (context, index) {
                final app = _apps[index];
                return _buildAppTile(app);

  Widget _buildAppTile(AppMemoryEntry app) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: AppTheme.primary.withOpacity(0.1),
        child: Text(
          app.displayName[0],
          style: const TextStyle(color: AppTheme.primary),
      title: Text(app.displayName, style: const TextStyle(color: AppTheme.textPrimary)),
      subtitle: Text(
        '${app.packageName} • ${app.category} • : ${app.useCount}',
        style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: Icon(
              app.isFavorite ? Icons.star : Icons.star_border,
              color: app.isFavorite ? AppTheme.accent : AppTheme.textSecondary,
            onPressed: () async {
              await _appMemory.toggleFavorite(app.packageName);
              _loadApps();
          IconButton(
            icon: const Icon(Icons.delete, color: AppTheme.error),
            onPressed: () async {
              await _appMemory.deleteApp(app.packageName);
              _loadApps();
      onTap: () {
        // Launch app

  Future<void> _searchApps(String query) async {
    if (query.isEmpty) {
      _loadApps();
      return;

    final results = await _appMemory.search(query);
    // Note: AppMemory.search doesn't exist in our implementation,
    // you'd need to add it or filter locally
    setState(() {
      _apps = results.where((app) =>
        app.displayName.toLowerCase().contains(query.toLowerCase()) ||
        app.nicknames.any((n) => n.toLowerCase().contains(query.toLowerCase()))
      ).toList();

  void _showAddAppDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('   ', style: TextStyle(color: AppTheme.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                labelText: ' ',
                labelStyle: TextStyle(color: AppTheme.textSecondary),
            const SizedBox(height: 8),
            TextField(
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                labelText: '  (com.example.app)',
                labelStyle: TextStyle(color: AppTheme.textSecondary),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('', style: TextStyle(color: AppTheme.textSecondary)),
          TextButton(
            onPressed: () {
              // Save logic
              Navigator.pop(context);
            child: const Text('', style: TextStyle(color: AppTheme.primary)),

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
}}}}}}}}}}}}}}}}}