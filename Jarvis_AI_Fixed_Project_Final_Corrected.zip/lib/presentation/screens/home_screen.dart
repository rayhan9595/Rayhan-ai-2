import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../config/routes.dart';
import '../../config/theme.dart';
import '../bloc/automation_bloc.dart';
import '../bloc/voice_bloc.dart';
import '../widgets/voice_button.dart';
import '../widgets/animated_ring.dart';
import '../widgets/app_launcher_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: _buildHeader(),
            SliverToBoxAdapter(
              child: _buildMainRing(),
            SliverToBoxAdapter(
              child: _buildActiveAutomations(),
            SliverToBoxAdapter(
              child: _buildAppMemorySection(),
            SliverToBoxAdapter(
              child: _buildRecentActivity(),
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: const VoiceButton(),

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            style: Theme.of(context).textTheme.headlineLarge,
          const SizedBox(height: 8),
          Text(
            'Jarvis   ',
            style: Theme.of(context).textTheme.bodyMedium,

  Widget _buildMainRing() {
    return const SizedBox(
      height: 250,
      child: Center(
        child: AnimatedStatusRing(
          status: RingStatus.idle,
          size: 200,

  Widget _buildActiveAutomations() {
    return BlocBuilder<AutomationBloc, AutomationState>(
      builder: (context, state) {
        final automations = state is AutomationLoaded ? state.automations : [];

        return Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.auto_mode, color: AppTheme.primary),
                  const SizedBox(width: 8),
                  Text(
                    '  (${automations.length})',
                    style: Theme.of(context).textTheme.titleLarge,
              const Divider(color: AppTheme.textSecondary),
              if (automations.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('   ',
                    style: TextStyle(color: AppTheme.textSecondary)),
              else
                ...automations.take(3).map((a) => ListTile(
                  leading: const Icon(Icons.check_circle, color: AppTheme.success),
                  title: Text(a.name, style: const TextStyle(color: AppTheme.textPrimary)),
                  subtitle: Text(a.triggerType, style: const TextStyle(color: AppTheme.textSecondary)),
                  dense: true,

  Widget _buildAppMemorySection() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.apps, color: AppTheme.secondary),
                  const SizedBox(width: 8),
                  Text(
                    style: Theme.of(context).textTheme.titleLarge,
              TextButton(
                onPressed: () => Navigator.pushNamed(context, Routes.appMemory),
                child: const Text(' '),
          const Divider(color: AppTheme.textSecondary),
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: const [
                AppLauncherTile(name: '', package: 'com.bkash.customerapp', icon: Icons.account_balance_wallet),
                AppLauncherTile(name: '', package: 'com.facebook.katana', icon: Icons.facebook),
                AppLauncherTile(name: '', package: 'com.google.android.youtube', icon: Icons.play_circle_fill),

  Widget _buildRecentActivity() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.history, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text(
                style: Theme.of(context).textTheme.titleLarge,
          const Divider(color: AppTheme.textSecondary),
          _buildActivityItem(' ', ': AM', true),
          _buildActivityItem(' ', ': AM', true),
          _buildActivityItem(' ', ': PM', false),

  Widget _buildActivityItem(String title, String time, bool completed) {
    return ListTile(
      leading: Icon(
        completed ? Icons.check_circle : Icons.pending,
        color: completed ? AppTheme.success : AppTheme.warning,
      title: Text(title, style: const TextStyle(color: AppTheme.textPrimary)),
      trailing: Text(time, style: const TextStyle(color: AppTheme.textSecondary)),
      dense: true,

  Widget _buildBottomNav() {
    return BottomNavigationBar(
      currentIndex: _selectedIndex,
      onTap: (index) {
        setState(() => _selectedIndex = index);
        if (index == 1) Navigator.pushNamed(context, Routes.chat);
        if (index == 2) Navigator.pushNamed(context, Routes.settings);
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: ''),
        BottomNavigationBarItem(icon: Icon(Icons.chat), label: ''),
        BottomNavigationBarItem(icon: Icon(Icons.settings), label: ''),
}}}}}}}}}}}}