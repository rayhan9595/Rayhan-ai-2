import 'package:flutter/material.dart';
import '../../config/theme.dart';

class WorkflowEditorScreen extends StatelessWidget {
  const WorkflowEditorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(title: const Text(' ')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.construction, size: 64, color: AppTheme.primary),
            const SizedBox(height: 16),
            Text(
              style: Theme.of(context).textTheme.headlineLarge,
            const SizedBox(height: 8),
            const Text(
              '-   ',
              style: TextStyle(color: AppTheme.textSecondary),
}}