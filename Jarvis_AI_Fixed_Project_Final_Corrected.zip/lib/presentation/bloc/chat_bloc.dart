import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/usecases/voice_command.dart';
import '../../core/ai_brain/nlp_processor.dart';

class ChatMessage extends Equatable {
  late final String text;
  late final bool isUser;
  late final DateTime timestamp;

  const ChatMessage({
    required this.text,
    required this.isUser,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  @override
  List<Object?> get props => [text, isUser, timestamp];

  Map<String, String> toApiMessage() {
    return {
      'role': isUser ? 'user' : 'assistant',
      'content': text,
    };
  }
}

abstract class ChatEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class SendMessageEvent extends ChatEvent {
  late final String text;
  SendMessageEvent(this.text);
  @override
  List<Object?> get props => [text];
}

class ClearChatEvent extends ChatEvent {}

abstract class ChatState extends Equatable {
  @override
  List<Object?> get props => [];
}

class ChatInitial extends ChatState {}
class ChatLoading extends ChatState {}
class ChatLoaded extends ChatState {
  late final List<ChatMessage> messages;
  ChatLoaded(this.messages);
  @override
  List<Object?> get props => [messages];
}

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final VoiceCommandUseCase _useCase = VoiceCommandUseCase();
  final NLPProcessor _nlpProcessor = NLPProcessor(); // Added NLPProcessor
  final List<ChatMessage> _messages = [];

  ChatBloc() : super(ChatInitial()) {
    on<SendMessageEvent>(_onSend);
    on<ClearChatEvent>(_onClear);
  }

  Future<void> _onSend(SendMessageEvent event, Emitter<ChatState> emit) async {
    _messages.add(ChatMessage(text: event.text, isUser: true));
    emit(ChatLoading());
    emit(ChatLoaded(List.from(_messages)));

    try {
      // Prepare chat history for the API call
      final chatHistory = _messages.map((msg) => msg.toApiMessage()).toList();

      // Pass chat history to the NLPProcessor
      final result = await _useCase.execute(event.text, chatHistory: chatHistory);
      _messages.add(ChatMessage(
        text: result.message,
        isUser: false,
      ));
      emit(ChatLoaded(List.from(_messages)));
    } catch (e) {
      _messages.add(ChatMessage(
        text: 'Error: $e',
        isUser: false,
      ));
      emit(ChatLoaded(List.from(_messages)));
    }
  }

  void _onClear(ClearChatEvent event, Emitter<ChatState> emit) {
    _messages.clear();
    emit(ChatInitial());
  }
}