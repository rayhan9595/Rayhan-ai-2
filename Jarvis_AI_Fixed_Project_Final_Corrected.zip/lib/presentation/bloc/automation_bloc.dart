import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../data/models/automation.dart';
import '../../data/repositories/automation_repo.dart';

abstract class AutomationEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadAutomationsEvent extends AutomationEvent {}

class AddAutomationEvent extends AutomationEvent {
  late final Automation automation;
  AddAutomationEvent(this.automation);
  @override
  List<Object?> get props => [automation];
}

abstract class AutomationState extends Equatable {
  @override
  List<Object?> get props => [];
}

class AutomationInitial extends AutomationState {}

class AutomationLoading extends AutomationState {}

class AutomationLoaded extends AutomationState {
  late final List<Automation> automations;
  AutomationLoaded(this.automations);
  @override
  List<Object?> get props => [automations];
}

class AutomationError extends AutomationState {
  late final String message;
  AutomationError(this.message);
  @override
  List<Object?> get props => [message];
}

class AutomationBloc extends Bloc<AutomationEvent, AutomationState> {
  final AutomationRepository _repo = AutomationRepository();

  AutomationBloc() : super(AutomationInitial()) {
    on<LoadAutomationsEvent>(_onLoad);
    on<AddAutomationEvent>(_onAdd);

    add(LoadAutomationsEvent());
  }

  Future<void> _onLoad(LoadAutomationsEvent event, Emitter<AutomationState> emit) async {
    emit(AutomationLoading());
    try {
      await _repo.initialize();
      final automations = await _repo.getActive();
      emit(AutomationLoaded(automations));
    } catch (e) {
      emit(AutomationError(e.toString()));
    }
  }

  Future<void> _onAdd(AddAutomationEvent event, Emitter<AutomationState> emit) async {
    await _repo.insert(event.automation);
    add(LoadAutomationsEvent());
  }
}
