import 'package:flutter/material.dart';
import '../../config/theme.dart';

enum RingStatus {
  idle,
  listening,
  processing,
  selfCoding,
  testing,
  executing,
  success,
  error,
  replying,
  permissionRequest,

class AnimatedStatusRing extends StatefulWidget {
  late final RingStatus status;
  late final double size;

  const AnimatedStatusRing({
    super.key,
    required this.status,
    this.size = 200,

  @override
  State<AnimatedStatusRing> createState() => _AnimatedStatusRingState();

class _AnimatedStatusRingState extends State<AnimatedStatusRing>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _rotateController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat();

  @override
  void didUpdateWidget(covariant AnimatedStatusRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.status != oldWidget.status) {
      _updateAnimation();

  void _updateAnimation() {
    switch (widget.status) {
      case RingStatus.idle:
        _pulseController.duration = const Duration(milliseconds: 2000);
        _rotateController.stop();
        break;
      case RingStatus.listening:
        _pulseController.duration = const Duration(milliseconds: 800);
        break;
      case RingStatus.processing:
        _rotateController.repeat();
        break;
      default:
        _pulseController.repeat(reverse: true);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseController, _rotateController]),
      builder: (context, child) {
        return Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [
                _getColor().withOpacity(0.2 + (_pulseController.value * 0.2)),
                _getColor().withOpacity(0.05),
            border: Border.all(
              color: _getColor().withOpacity(0.5 + (_pulseController.value * 0.5)),
              width: 2 + (_pulseController.value * 2),
          child: Center(
            child: Transform.rotate(
              angle: widget.status == RingStatus.processing
                ? _rotateController.value * 2 * 3.14159
                : 0,
              child: Icon(
                _getIcon(),
                size: widget.size * 0.3,
                color: _getColor(),

  Color _getColor() {
    switch (widget.status) {
      case RingStatus.idle:
        return AppTheme.primary;
      case RingStatus.listening:
        return AppTheme.secondary;
      case RingStatus.processing:
        return AppTheme.accent;
      case RingStatus.selfCoding:
        return AppTheme.primary;
      case RingStatus.testing:
        return AppTheme.warning;
      case RingStatus.executing:
        return AppTheme.primary;
      case RingStatus.success:
        return AppTheme.success;
      case RingStatus.error:
        return AppTheme.error;
      case RingStatus.replying:
        return AppTheme.primary;
      case RingStatus.permissionRequest:
        return AppTheme.warning;

  IconData _getIcon() {
    switch (widget.status) {
      case RingStatus.idle:
        return Icons.smart_toy;
      case RingStatus.listening:
        return Icons.mic;
      case RingStatus.processing:
        return Icons.memory;
      case RingStatus.selfCoding:
        return Icons.code;
      case RingStatus.testing:
        return Icons.bug_report;
      case RingStatus.executing:
        return Icons.play_arrow;
      case RingStatus.success:
        return Icons.check;
      case RingStatus.error:
        return Icons.error;
      case RingStatus.replying:
        return Icons.chat;
      case RingStatus.permissionRequest:
        return Icons.security;

  @override
  void dispose() {
    _pulseController.dispose();
    _rotateController.dispose();
    super.dispose();
}}}}}}}}}}}}}}}}