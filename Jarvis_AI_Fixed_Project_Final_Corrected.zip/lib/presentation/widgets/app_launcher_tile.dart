import 'package:flutter/material.dart';
import '../../config/theme.dart';
import '../../services/device/app_launcher_service.dart';
import '../../core/memory/app_memory.dart';

class AppLauncherTile extends StatelessWidget {
  late final String name;
  late final String package;
  late final IconData icon;

  const AppLauncherTile({
    super.key,
    required this.name,
    required this.package,
    required this.icon,

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final launcher = AppLauncherService();
        final success = await launcher.launchApp(package);

        if (success) {
          final memory = AppMemory();
          await memory.recordUsage(package);
      child: Container(
        width: 80,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: AppTheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              child: Icon(icon, color: AppTheme.primary, size: 28),
            const SizedBox(height: 8),
            Text(
              name,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 12,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
}}}}}