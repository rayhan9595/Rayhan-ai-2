import 'dart:io';
import 'package:path_provider/path_provider.dart';

class Logger {
  static final Logger _instance = Logger._internal();
  factory Logger() => _instance;
  Logger._internal();

  File? _logFile;

  Future<void> initialize() async {
    final dir = await getApplicationDocumentsDirectory();
    _logFile = File('${dir.path}/jarvis_logs.txt');

  void log(String tag, String message, {String level = 'INFO'}) async {
    final timestamp = DateTime.now().toIso8601String();
    final logLine = '[$timestamp] [$level] [$tag] $message\n';

    print(logLine);

    if (_logFile != null) {
      await _logFile!.writeAsString(logLine, mode: FileMode.append);

  void error(String tag, String message, [StackTrace? stackTrace]) {
    log(tag, '$message\n${stackTrace ?? ''}', level: 'ERROR');

  void debug(String tag, String message) {
    log(tag, message, level: 'DEBUG');
}}}}}}