import '../../core/ai_brain/intent_classifier.dart';
import '../../core/ai_brain/entity_extractor.dart';
import '../../core/ai_brain/response_generator.dart';
import '../../core/automation_engine/action_executor.dart';
import '../../core/memory/context_manager.dart';
import '../../services/permission/permission_router.dart';

class VoiceCommandResult {
  late final bool success;
  late final String intent;
  late final String message;
  late final Map<String, dynamic>? data;

  VoiceCommandResult({
    required this.success,
    required this.intent,
    required this.message,
    this.data,
  });
}

class VoiceCommandUseCase {
  final IntentClassifier _classifier = IntentClassifier();
  final EntityExtractor _extractor = EntityExtractor();
  final ResponseGenerator _response = ResponseGenerator();
  final ActionExecutor _executor = ActionExecutor();
  final ContextManager _context = ContextManager();
  final PermissionRouter _permission = PermissionRouter();

  Future<VoiceCommandResult> execute(String command, {List<Map<String, String>? chatHistory}) async {
    try {
      // Store in context
      _context.addCommandToHistory(command);

      // Classify intent
      final intentResult = await _classifier.classify(command, chatHistory: chatHistory);
      final entities = _extractor.extract(intentResult.entities);

      // Check permission if needed
      if (intentResult.requiresPermission) {
        final permType = _inferPermissionType(intentResult.primaryIntent);
        final hasPermission = await _permission.checkAndRoute(permType);
        if (!hasPermission) {
          return VoiceCommandResult(
            success: false,
            intent: intentResult.primaryIntent,
            message: 'Permission denied for ${intentResult.primaryIntent}',
          );
        }
      }

      // Execute based on intent
      final result = await _executeIntent(intentResult.primaryIntent, entities);

      // Generate response
      await _response.generate(
        intent: intentResult.primaryIntent,
        success: result.success,
        data: result.data,
      );

      return VoiceCommandResult(
        success: true,
        intent: intentResult.primaryIntent,
        message: _response.lastResponse,
        data: result.data,
      );
    } catch (e) {
      print('VoiceCommandUseCase Error: $e');
      return VoiceCommandResult(
        success: false,
        intent: 'error',
        message: 'An error occurred: $e',
      );
    }
  }

  Future<PermissionType> _inferPermissionType(String intent) async {
    switch (intent) {
      case 'call_contact':
      case 'send_sms':
        return PermissionType.contacts;
      case 'open_app':
      case 'control_device':
        return PermissionType.systemAlertWindow; // Or other relevant permission
      case 'camera_capture':
        return PermissionType.camera;
      case 'read_contacts':
        return PermissionType.contacts;
      case 'access_location':
        return PermissionType.location;
      default:
        return PermissionType.none;
    }
  }

  Future<VoiceCommandResult> _executeIntent(String intent, ExtractedEntities entities) async {
    switch (intent) {
      case 'open_app':
        return await _executor.openApp(entities.appName);
      case 'set_alarm':
        return await _executor.setAlarm(entities.dateTime);
      case 'set_reminder':
        return await _executor.setReminder(entities.dateTime, entities.message);
      case 'call_contact':
        return await _executor.callContact(entities.contactName, entities.phoneNumber);
      case 'send_sms':
        return await _executor.sendSms(entities.phoneNumber, entities.message);
      case 'check_weather':
        return await _executor.checkWeather(entities.location);
      case 'read_news':
        return await _executor.readNews(entities.query);
      case 'control_device':
        return await _executor.controlDevice(entities.deviceName, entities.action);
      case 'create_workflow':
        return await _executor.createWorkflow();
      case 'search_web':
        return await _executor.searchWeb(entities.query);
      case 'translate':
        return await _executor.translate(entities.query, entities.language);
      case 'take_note':
        return await _executor.takeNote(entities.message);
      case 'schedule_event':
        return await _executor.scheduleEvent(entities.dateTime, entities.message);
      case 'self_update':
        return await _executor.selfUpdate();
      case 'permission_request':
        return await _executor.requestPermission();
      default:
        return VoiceCommandResult(success: false, intent: 'unknown', message: 'Unknown command');
    }
  }
}