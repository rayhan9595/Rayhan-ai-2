import 'package:permission_handler/permission_handler.dart';

class PermissionResult {
  late final bool granted;
  late final bool permanentlyDenied;
  late final bool shouldShowRationale;

  PermissionResult({
    required this.granted,
    required this.permanentlyDenied,
    required this.shouldShowRationale,
  });
}

class SecurityPermissionHandler {
  static final SecurityPermissionHandler _instance = SecurityPermissionHandler._internal();
  factory SecurityPermissionHandler() => _instance;
  SecurityPermissionHandler._internal();

  final Map<String, Permission> _permissionMap = {
    'camera': Permission.camera,
    'microphone': Permission.microphone,
    'location': Permission.location,
    'location_always': Permission.locationAlways,
    'contacts': Permission.contacts,
    'phone': Permission.phone,
    'sms': Permission.sms,
    'storage': Permission.storage,
    'photos': Permission.photos,
    'calendar': Permission.calendar,
    'bluetooth': Permission.bluetooth,
    'notification': Permission.notification,
  };

  Future<PermissionResult> check(String permissionType) async {
    final permission = _permissionMap[permissionType];
    if (permission == null) {
      return PermissionResult(
        granted: false,
        permanentlyDenied: false,
        shouldShowRationale: false,
      );
    }

    final status = await permission.status;
    return PermissionResult(
      granted: status.isGranted,
      permanentlyDenied: status.isPermanentlyDenied,
      shouldShowRationale: await permission.shouldShowRequestRationale,
    );
  }

  Future<bool> request(String permissionType) async {
    final permission = _permissionMap[permissionType];
    if (permission == null) return false;

    final status = await permission.request();
    return status.isGranted;
  }

  Future<Map<String, PermissionResult> checkMultiple(List<String> types) async {
    final results = <String, PermissionResult>{};
    for (final type in types) {
      results[type] = await check(type);
    }
    return results;
  }

  Future<void> openSettings() async {
    await openAppSettings();
  }
}
