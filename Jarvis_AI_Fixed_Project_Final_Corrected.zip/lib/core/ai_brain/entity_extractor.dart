import 'package:intl/intl.dart';

class ExtractedEntities {
  late final String? appName;
  late final DateTime? dateTime;
  late final String? contactName;
  late final String? phoneNumber;
  late final String? message;
  late final String? location;
  late final String? query;
  late final String? language;
  late final String? deviceName;
  late final String? action;
  late final int? priority;
  late final bool? recurring;

  ExtractedEntities({
    this.appName,
    this.dateTime,
    this.contactName,
    this.phoneNumber,
    this.message,
    this.location,
    this.query,
    this.language,
    this.deviceName,
    this.action,
    this.priority,
    this.recurring,
  });
}

class EntityExtractor {
  static final EntityExtractor _instance = EntityExtractor._internal();
  factory EntityExtractor() => _instance;
  EntityExtractor._internal();

  ExtractedEntities extract(Map<String, dynamic> entities) {
    return ExtractedEntities(
      appName: entities['app_name']?.toString(),
      dateTime: _parseDateTime(entities['time']?.toString(), entities['date']?.toString()),
      contactName: entities['contact']?.toString(),
      phoneNumber: _extractPhoneNumber(entities['contact']?.toString()),
      message: entities['message']?.toString(),
      location: entities['location']?.toString(),
      query: entities['query']?.toString(),
      language: entities['language']?.toString() ?? 'bn',
      deviceName: entities['device']?.toString(),
      action: entities['action']?.toString(),
      priority: entities['priority'] as int?,
      recurring: entities['recurring'] as bool?,
    );
  }

  DateTime? _parseDateTime(String? timeStr, String? dateStr) {
    if (timeStr == null) return null;

    try {
      final now = DateTime.now();
      final parts = timeStr.split(':');
      final hour = int.parse(parts[0]);
      final minute = parts.length > 1 ? int.parse(parts[1]) : 0;

      DateTime result = DateTime(now.year, now.month, now.day, hour, minute);

      if (dateStr != null) {
        final dateParts = dateStr.split('-');
        if (dateParts.length == 3) {
          result = DateTime(
            int.parse(dateParts[0]),
            int.parse(dateParts[1]),
            int.parse(dateParts[2]),
            hour,
            minute,
          );
        }
      }

      if (result.isBefore(now)) {
        result = result.add(const Duration(days: 1));
      }

      return result;
    } catch (e) {
      return null;
    }
  }

  String? _extractPhoneNumber(String? text) {
    if (text == null) return null;
    final pattern = RegExp(r'01[3-9]\d{8}');
    final match = pattern.firstMatch(text);
    return match?.group(0);
  }
}
