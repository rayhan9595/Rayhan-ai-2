import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ApiConfig {
  late final String baseUrl;
  late final String apiKey;
  late final String modelName;

  ApiConfig({
    required this.baseUrl,
    required this.apiKey,
    required this.modelName,
  });

  Map<String, dynamic> toJson() => {
        'baseUrl': baseUrl,
        'apiKey': apiKey,
        'modelName': modelName,
      };

  static ApiConfig fromJson(Map<String, dynamic> json) => ApiConfig(
        baseUrl: json['baseUrl'],
        apiKey: json['apiKey'],
        modelName: json['modelName'],
      );
}

class ApiConfigService {
  static const String _apiConfigKey = 'api_config';

  Future<void> saveApiConfig(ApiConfig config) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_apiConfigKey, jsonEncode(config.toJson()));
  }

  Future<ApiConfig?> getApiConfig() async {
    final prefs = await SharedPreferences.getInstance();
    final String? configString = prefs.getString(_apiConfigKey);
    if (configString == null) {
      return null;
    }
    return ApiConfig.fromJson(jsonDecode(configString));
  }

  Future<void> clearApiConfig() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_apiConfigKey);
  }
}