import 'dart:io';
import 'package:device_apps/device_apps.dart';
import 'package:url_launcher/url_launcher.dart';

class AppLauncherService {
  static final AppLauncherService _instance = AppLauncherService._internal();
  factory AppLauncherService() => _instance;
  AppLauncherService._internal();

  Future<bool> launchApp(String packageName) async {
    try {
      return await DeviceApps.openApp(packageName);
    } catch (e) {
      return false;

  Future<bool> findAndLaunchApp(String appName) async {
    try {
      final apps = await DeviceApps.getInstalledApplications(
        includeAppIcons: false,
        includeSystemApps: true,
        onlyAppsWithLaunchIntent: true,

      // Fuzzy match
      final matched = apps.where((app) {
        final name = app.appName.toLowerCase();
        final query = appName.toLowerCase();
        return name.contains(query) || query.contains(name);
      }).toList();

      if (matched.isNotEmpty) {
        return await DeviceApps.openApp(matched.first.packageName);

      return false;
    } catch (e) {
      return false;

  Future<void> openPlayStore(String appName) async {
    final uri = Uri.parse('market://search?q=$appName');
    final webUri = Uri.parse('https://play.google.com/store/search?q=$appName');

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else if (await canLaunchUrl(webUri)) {
      await launchUrl(webUri, mode: LaunchMode.externalApplication);

  Future<List<Application> getInstalledApps() async {
    return await DeviceApps.getInstalledApplications(
      includeAppIcons: true,
      onlyAppsWithLaunchIntent: true,
}}}}}}}}}