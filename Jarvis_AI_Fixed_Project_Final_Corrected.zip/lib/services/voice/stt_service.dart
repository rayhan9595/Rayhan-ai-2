import 'dart:async';
import 'package:speech_to_text/speech_to_text.dart';

class STTService {
  static final STTService _instance = STTService._internal();
  factory STTService() => _instance;
  STTService._internal();

  final SpeechToText _speech = SpeechToText();
  bool _isInitialized = false;

  Future<void> initialize() async {
    if (_isInitialized) return;
    _isInitialized = await _speech.initialize(
      onError: (error) => print('STT Error: $error'),
      onStatus: (status) => print('STT Status: $status'),

  Future<String> listen({
    String localeId = 'bn_BD',
    Duration timeout = const Duration(seconds: 10),
  }) async {
    if (!_isInitialized) await initialize();
    if (!_speech.isAvailable) return '';

    final completer = Completer<String>();
    String recognizedText = '';

    await _speech.listen(
      onResult: (result) {
        recognizedText = result.recognizedWords;
        if (result.finalResult) {
          if (!completer.isCompleted) {
            completer.complete(recognizedText);
      localeId: localeId,
      listenMode: ListenMode.confirmation,
      pauseFor: const Duration(seconds: 3),

    // Timeout fallback
    Timer(timeout, () {
      if (!completer.isCompleted) {
        _speech.stop();
        completer.complete(recognizedText);

    return completer.future;

  Future<void> stop() async {
    await _speech.stop();

  bool get isListening => _speech.isListening;

  void dispose() {
    _speech.cancel();
}}}}}}}}}}