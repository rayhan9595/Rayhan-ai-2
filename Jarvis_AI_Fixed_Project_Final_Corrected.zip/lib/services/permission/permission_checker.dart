import '../../core/security/permission_handler.dart';

class PermissionChecker {
  static final PermissionChecker _instance = PermissionChecker._internal();
  factory PermissionChecker() => _instance;
  PermissionChecker._internal();

  final SecurityPermissionHandler _handler = SecurityPermissionHandler();

  Future<bool> check(String permissionType) async {
    final result = await _handler.check(permissionType);
    return result.granted;

  Future<Map<String, bool> checkMultiple(List<String> types) async {
    final results = await _handler.checkMultiple(types);
    return results.map((key, value) => MapEntry(key, value.granted));

  Future<bool> request(String permissionType) async {
    return await _handler.request(permissionType);
}}}}