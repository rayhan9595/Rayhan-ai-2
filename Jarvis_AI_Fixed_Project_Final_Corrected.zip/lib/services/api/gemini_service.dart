import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../services/api_config_service.dart';
import '../../config/constants.dart';

class GeminiService {
  static final GeminiService _instance = GeminiService._internal();
  factory GeminiService() => _instance;
  GeminiService._internal();

  ApiConfig? _apiConfig;

  Future<void> initialize() async {
    _model = GenerativeModel(
      model: 'gemini-pro',
      apiKey: Constants.geminiApiKey,

  Future<String> generateContent(String prompt) async {
    if (_model == null) await initialize();

    try {
      final response = await _model!.generateContent([Content.text(prompt)]);
      return response.text ?? '   ';
    } catch (e) {
      return ': $e';

  Future<String> analyzeIntent(String text) async {
    final prompt = '''
    Analyze this command for a personal AI assistant.
    Command: "$text"
    Respond with just the intent name.

    return await generateContent(prompt);
}}}}}