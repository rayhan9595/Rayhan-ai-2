import 'package:flutter_test/flutter_test.dart';
import 'package:self_aware_automation/core/self_aware/self_deployer.dart';

void main() {
  group('Rollback Tests', () {
    final deployer = SelfDeployer();

    test('Rollback removes deployed feature', () async {
      final success = await deployer.rollback('test_feature');
      expect(success, true);