import 'package:flutter_test/flutter_test.dart';
import 'package:self_aware_automation/core/self_aware/self_tester.dart';
import 'package:self_aware_automation/core/self_aware/self_generator.dart';

void main() {
  group('Sandbox Tests', () {
    final tester = SelfTester();

    test('Valid workflow passes sandbox', () async {
      final code = GeneratedCode(
        featureName: 'test_feature',
        code: '{"feature": "test", "version": "1.0"}',
        filePath: 'test.json',
        dependencies: [],

      final result = await tester.runSandboxTest(code);
      expect(result.passed, true);
      expect(result.executionTimeMs, lessThan(5000));

    test('Harmful pattern detected', () async {
      final code = GeneratedCode(
        featureName: 'malicious',
        code: '{"while(true)": "infinite_loop"}',
        filePath: 'bad.json',
        dependencies: [],

      final result = await tester.runSandboxTest(code);
      expect(result.passed, false);