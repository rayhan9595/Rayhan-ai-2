import 'package:flutter_test/flutter_test.dart';
import 'package:self_aware_automation/core/self_aware/self_generator.dart';
import 'package:self_aware_automation/core/self_aware/self_analyzer.dart';

void main() {
  group('Code Generation Tests', () {
    final generator = SelfGenerator();
    final analyzer = SelfAnalyzer();

    test('Generate weekly report feature', () async {
      final analysis = NeedAnalysis(
        featureName: 'weekly_report',
        description: 'Weekly report',
        requiredModules: ['scheduler'],
        complexity: 3,

      final code = await generator.generate(analysis);
      expect(code.featureName, 'weekly_report');
      expect(code.code.contains('weekly_report'), true);