import 'package:sqflite/sqflite.dart';
import '../models/workflow.dart';
import '../datasources/local/sqlite_db.dart';

class WorkflowRepository {
  static final WorkflowRepository _instance = WorkflowRepository._internal();
  factory WorkflowRepository() => _instance;
  WorkflowRepository._internal();

  Database? _db;

  Future<void> initialize() async {
    _db = await SQLiteDB().database;
    await _createTable();

  Future<void> _createTable() async {
    await _db?.execute('''
      CREATE TABLE IF NOT EXISTS workflows (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        trigger_type TEXT NOT NULL,
        trigger_keyword TEXT,
        conditions TEXT,
        condition_logic TEXT DEFAULT 'AND',
        actions TEXT,
        is_active INTEGER DEFAULT 1,
        next_run_time TEXT,
        latitude REAL,
        longitude REAL,
        radius REAL,
        voice_confirmation INTEGER DEFAULT 1

  Future<void> insert(Workflow workflow) async {
    await _db?.insert(
      'workflows',
      workflow.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,

  Future<List<<Workflow>> getAll() async {
    final results = await _db?.query('workflows');
    return results?.map((r) => Workflow.fromJson(r)).toList() ?? [];

  Future<List<<Workflow>> getActiveWorkflows() async {
    final results = await _db?.query(
      'workflows',
      where: 'is_active = ?',
      whereArgs: [1],
    return results?.map((r) => Workflow.fromJson(r)).toList() ?? [];

  Future<List<<Workflow>> getTimeBasedWorkflows() async {
    final results = await _db?.query(
      'workflows',
      where: 'trigger_type = ? AND is_active = ?',
      whereArgs: ['time', 1],
    return results?.map((r) => Workflow.fromJson(r)).toList() ?? [];

  Future<<Workflow?> getById(String id) async {
    final results = await _db?.query(
      'workflows',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    if (results == null || results.isEmpty) return null;
    return Workflow.fromJson(results.first);

  Future<void> logExecution(String id, bool success, {String? errorMessage}) async {
    await _db?.insert('workflow_logs', {
      'workflow_id': id,
      'success': success ? 1 : 0,
      'error_message': errorMessage,
      'executed_at': DateTime.now().toIso8601String(),

  Future<void> delete(String id) async {
    await _db?.delete(
      'workflows',
      where: 'id = ?',
      whereArgs: [id],