import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../models/app_memory_model.dart';
import '../datasources/local/sqlite_db.dart';

class AppMemoryRepository {
  static final AppMemoryRepository _instance = AppMemoryRepository._internal();
  factory AppMemoryRepository() => _instance;
  AppMemoryRepository._internal();

  Database? _db;

  Future<void> initialize() async {
    _db = await SQLiteDB().database;

  Future<void> save(AppMemoryModel app) async {
    await _db?.insert(
      'app_memory',
        'display_name': app.displayName,
        'package_name': app.packageName,
        'nicknames': jsonEncode(app.nicknames),
        'category': app.category,
        'usage_pattern': jsonEncode(app.usagePattern),
        'last_used': app.lastUsed?.toIso8601String(),
        'is_favorite': app.isFavorite ? 1 : 0,
        'use_count': app.useCount,
      conflictAlgorithm: ConflictAlgorithm.replace,

  Future<List<<AppMemoryModel>> search(String query) async {
    final results = await _db?.query(
      'app_memory',
      where: 'display_name LIKE ? OR nicknames LIKE ? OR package_name LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'use_count DESC',

    return results?.map((r) => AppMemoryModel(
      displayName: r['display_name'] as String,
      packageName: r['package_name'] as String,
      nicknames: List<String>.from(jsonDecode(r['nicknames'] as String)),
      category: r['category'] as String,
      usagePattern: List<String>.from(jsonDecode(r['usage_pattern'] as String)),
      lastUsed: r['last_used'] != null ? DateTime.parse(r['last_used'] as String) : null,
      isFavorite: (r['is_favorite'] as int) == 1,
      useCount: r['use_count'] as int,
    )).toList() ?? [];

  Future<void> incrementUsage(String packageName) async {
    await _db?.rawUpdate('''
      UPDATE app_memory
      SET use_count = use_count + 1, last_used = ?
      WHERE package_name = ?
    ''', [DateTime.now().toIso8601String(), packageName]);