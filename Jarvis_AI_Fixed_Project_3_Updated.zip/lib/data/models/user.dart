class User {
  final String id;
  final String name;
  final String? email;
  final String? phone;
  final String preferredLanguage;
  final String? address;
  final Map<String, dynamic> preferences;
  final DateTime createdAt;
  final DateTime? lastActive;

  User({
    required this.id,
    required this.name,
    this.email,
    this.phone,
    this.preferredLanguage = 'bn',
    this.address,
    this.preferences = const {},
    DateTime? createdAt,
    this.lastActive,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'email': email,
    'phone': phone,
    'preferred_language': preferredLanguage,
    'address': address,
    'preferences': preferences,
    'created_at': createdAt.toIso8601String(),
    'last_active': lastActive?.toIso8601String(),

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json['id'],
    name: json['name'],
    email: json['email'],
    phone: json['phone'],
    preferredLanguage: json['preferred_language'] ?? 'bn',
    address: json['address'],
    preferences: json['preferences'] ?? {},
    createdAt: DateTime.parse(json['created_at']),
    lastActive: json['last_active'] != null ? DateTime.parse(json['last_active']) : null,