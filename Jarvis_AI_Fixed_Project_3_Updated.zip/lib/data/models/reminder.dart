class Reminder {
  final String id;
  final String title;
  final String? description;
  final DateTime triggerTime;
  final bool isRecurring;
  final String? recurrenceRule;
  final String? location;
  final double? latitude;
  final double? longitude;
  final bool isCompleted;
  final String? category;
  final int priority; // 1-5

  Reminder({
    required this.id,
    required this.title,
    this.description,
    required this.triggerTime,
    this.isRecurring = false,
    this.recurrenceRule,
    this.location,
    this.latitude,
    this.longitude,
    this.isCompleted = false,
    this.category,
    this.priority = 3,

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'trigger_time': triggerTime.toIso8601String(),
    'is_recurring': isRecurring ? 1 : 0,
    'recurrence_rule': recurrenceRule,
    'location': location,
    'latitude': latitude,
    'longitude': longitude,
    'is_completed': isCompleted ? 1 : 0,
    'category': category,
    'priority': priority,

  factory Reminder.fromJson(Map<String, dynamic> json) => Reminder(
    id: json['id'],
    title: json['title'],
    description: json['description'],
    triggerTime: DateTime.parse(json['trigger_time']),
    isRecurring: json['is_recurring'] == 1,
    recurrenceRule: json['recurrence_rule'],
    location: json['location'],
    latitude: json['latitude'],
    longitude: json['longitude'],
    isCompleted: json['is_completed'] == 1,
    category: json['category'],
    priority: json['priority'] ?? 3,