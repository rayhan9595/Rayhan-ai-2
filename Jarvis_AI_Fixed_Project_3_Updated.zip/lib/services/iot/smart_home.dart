import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

class SmartDevice {
  final String id;
  final String name;
  final String type;
  final String room;
  bool isOnline;
  Map<String, dynamic> state;

  SmartDevice({
    required this.id,
    required this.name,
    required this.type,
    required this.room,
    this.isOnline = false,
    this.state = const {},

class SmartHomeService {
  static final SmartHomeService _instance = SmartHomeService._internal();
  factory SmartHomeService() => _instance;
  SmartHomeService._internal();

  MqttServerClient? _client;
  final Map<String, SmartDevice> _devices = {};
  final _deviceController = StreamController<List<<SmartDevice>>.broadcast();

  Stream<List<<SmartDevice>> get deviceStream => _deviceController.stream;

  Future<void> connect(String broker, {int port = 1883}) async {
    _client = MqttServerClient(broker, 'jarvis_client');
    _client!.port = port;
    _client!.keepAlivePeriod = 20;

    final connMessage = MqttConnectMessage()
      .withClientIdentifier('jarvis_client')
      .startClean()
      .withWillQos(MqttQos.atLeastOnce);

    _client!.connectionMessage = connMessage;

    try {
      await _client!.connect();
      _client!.updates!.listen((messages) {
        for (final msg in messages) {
          final payload = MqttPublishMessage.toString();
          _handleMessage(msg.topic, payload);
    } catch (e) {
      print('MQTT Connection Error: $e');

  void _handleMessage(String topic, String payload) {
    // Parse device state updates

  Future<void> sendCommand(String deviceId, String command, dynamic value) async {
    if (_client?.connectionStatus?.state != MqttConnectionState.connected) {
      return;

    final topic = 'jarvis/devices/$deviceId/command';
    final message = jsonEncode({
      'command': command,
      'value': value,
      'timestamp': DateTime.now().toIso8601String(),

    final builder = MqttClientPayloadBuilder();
    builder.addString(message);

    _client!.publishMessage(topic, MqttQos.atLeastOnce, builder.payload!);

  Future<void> discoverDevices() async {
    // Send discovery message
    await sendCommand('broadcast', 'discover', null);

  void disconnect() {
    _client?.disconnect();