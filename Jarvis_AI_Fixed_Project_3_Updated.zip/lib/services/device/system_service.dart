import 'dart:io';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class SystemService {
  static final SystemService _instance = SystemService._internal();
  factory SystemService() => _instance;
  SystemService._internal();

  final Battery _battery = Battery();
  final Connectivity _connectivity = Connectivity();
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();

  Future<int> getBatteryLevel() async {
    return await _battery.batteryLevel;

  Future<bool> isWifiEnabled() async {
    final result = await _connectivity.checkConnectivity();
    return result == ConnectivityResult.wifi;

  Future<bool> isBluetoothEnabled() async {
    // Use platform channel
    return false;

  Future<void> setWifiEnabled(bool enabled) async {
    // Use platform channel or Settings intent
    await MethodChannel('com.jarvis/system').invokeMethod('setWifi', {'enabled': enabled});

  Future<void> setBluetoothEnabled(bool enabled) async {
    await MethodChannel('com.jarvis/system').invokeMethod('setBluetooth', {'enabled': enabled});

  Future<void> setBrightness(double level) async {
    // level: 0.0 to 1.0
    await MethodChannel('com.jarvis/system').invokeMethod('setBrightness', {'level': level});

  Future<void> setVolume(double level) async {
    await MethodChannel('com.jarvis/system').invokeMethod('setVolume', {'level': level});

  Future<void> setAirplaneMode(bool enabled) async {
    await MethodChannel('com.jarvis/system').invokeMethod('setAirplaneMode', {'enabled': enabled});

  Future<void> setFlashlight(bool enabled) async {
    await MethodChannel('com.jarvis/system').invokeMethod('setFlashlight', {'enabled': enabled});

  Future<String?> getCurrentLocationName() async {
    try {
      final position = await Geolocator.getCurrentPosition();
      // Use geocoding to get name
      return '${position.latitude},${position.longitude}';
    } catch (e) {
      return null;

  Future<bool> isAppRunning(String packageName) async {
    final result = await MethodChannel('com.jarvis/system').invokeMethod('isAppRunning', {'package': packageName});
    return result ?? false;

  Future<void> showNotification(String title, String body, {String? payload}) async {
    const androidDetails = AndroidNotificationDetails(
      'jarvis_channel',
      'Jarvis Notifications',
      channelDescription: 'Primary notification channel for Jarvis AI',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: true,

    const details = NotificationDetails(android: androidDetails);

    await _notifications.show(
      DateTime.now().millisecond,
      title,
      body,
      details,
      payload: payload,

  Future<void> launchURL(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);

  Future<void> takeScreenshot() async {
    await MethodChannel('com.jarvis/system').invokeMethod('takeScreenshot');