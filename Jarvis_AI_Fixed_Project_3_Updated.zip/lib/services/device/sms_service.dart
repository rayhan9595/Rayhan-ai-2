import 'package:url_launcher/url_launcher.dart';

class SMSService {
  static final SMSService _instance = SMSService._internal();
  factory SMSService() => _instance;
  SMSService._internal();

  Future<void> sendSMS(String number, String message) async {
    final uri = Uri.parse('sms:$number?body=${Uri.encodeComponent(message)}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);

  Future<void> openMessagingApp() async {
    final uri = Uri.parse('sms:');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);