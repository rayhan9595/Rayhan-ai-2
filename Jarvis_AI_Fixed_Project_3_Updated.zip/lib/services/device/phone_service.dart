import 'dart:io';
import 'package:url_launcher/url_launcher.dart';

class PhoneService {
  static final PhoneService _instance = PhoneService._internal();
  factory PhoneService() => _instance;
  PhoneService._internal();

  Future<void> call(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);

  Future<void> openDialer(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);

  Future<void> openContacts() async {
    // Use platform channel for native contacts