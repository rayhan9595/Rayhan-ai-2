import 'package:shared_preferences/shared_preferences.dart';

class PermissionMemory {
  static final PermissionMemory _instance = PermissionMemory._internal();
  factory PermissionMemory() => _instance;
  PermissionMemory._internal();

  Future<String?> getPermissionState(String permissionType) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('perm_$permissionType');

  Future<void> savePermissionState(String permissionType, String state) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('perm_$permissionType', state);
    await prefs.setInt('perm_${permissionType}_count',
      (prefs.getInt('perm_${permissionType}_count') ?? 0) + 1);

  Future<int> getAskCount(String permissionType) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('perm_${permissionType}_count') ?? 0;

  Future<void> resetPermission(String permissionType) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('perm_$permissionType');
    await prefs.remove('perm_${permissionType}_count');