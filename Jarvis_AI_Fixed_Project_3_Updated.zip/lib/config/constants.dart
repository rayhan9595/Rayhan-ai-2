class Constants {
  static const String appName = 'Jarvis AI';
  static const String wakeWord = 'Hey Jarvis';
  static const String dbName = 'jarvis_db.db';

  // Default API configuration (can be overridden by user settings)
  static const String defaultApiBaseUrl = 'https://api.openai.com/v1'; // Example for OpenAI-compatible API
  static const String defaultApiModelName = 'gpt-3.5-turbo'; // Example model
  static const String defaultApiKey = ''; // Should be empty or a placeholder, user will provide

  static const String openWeatherApiKey = 'YOUR_OPENWEATHER_API_KEY';
  static const String newsApiKey = 'YOUR_NEWS_API_KEY';

  // Limits
  static const int maxSandboxTimeMs = 5000;
  static const double maxSandboxCpuPercent = 30.0;
  static const int maxSandboxRamMB = 100;

  // Personality
  static const String addressMale = 'Sir';
  static const String addressFemale = 'Ma\'am';

  static const List<String> successReplies = [
    'Task completed, sir. What next?',
    'Automation successfully initiated.',
    'Process finished, anything else?',
  ];

  static const List<String> errorReplies = [
    'Apologies, sir, I am correcting that.',
    'There was an issue, rolling back.',
    'I encountered a problem, please check the logs.',
  ];
}