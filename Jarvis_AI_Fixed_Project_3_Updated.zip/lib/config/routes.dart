class Routes {
  static const String home = '/';
  static const String chat = '/chat';
  static const String automationBuilder = '/automation';
  static const String workflowEditor = '/workflow';
  static const String settings = '/settings';
  static const String analytics = '/analytics';
  static const String appMemory = '/app-memory';
}
