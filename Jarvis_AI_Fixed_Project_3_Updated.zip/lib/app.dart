import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'presentation/bloc/automation_bloc.dart';
import 'presentation/bloc/voice_bloc.dart';
import 'presentation/bloc/chat_bloc.dart';
import 'presentation/bloc/self_aware_bloc.dart';
import 'presentation/screens/home_screen.dart';
import 'presentation/screens/chat_screen.dart';
import 'presentation/screens/automation_builder.dart';
import 'presentation/screens/workflow_editor.dart';
import 'presentation/screens/settings_screen.dart';
import 'presentation/screens/analytics_screen.dart';
import 'presentation/screens/app_memory_screen.dart';
import 'config/theme.dart';
import 'config/routes.dart';

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => AutomationBloc()),
        BlocProvider(create: (_) => VoiceBloc()),
        BlocProvider(create: (_) => ChatBloc()),
        BlocProvider(create: (_) => SelfAwareBloc()),
      ],
      child: MaterialApp(
        title: 'Jarvis - Self-Aware Automation',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        initialRoute: Routes.home,
        routes: {
          Routes.home: (context) => const HomeScreen(),
          Routes.chat: (context) => const ChatScreen(),
          Routes.automationBuilder: (context) => const AutomationBuilderScreen(),
          Routes.workflowEditor: (context) => const WorkflowEditorScreen(),
          Routes.settings: (context) => const SettingsScreen(),
          Routes.analytics: (context) => const AnalyticsScreen(),
          Routes.appMemory: (context) => const AppMemoryScreen(),
        },
      ),
    );
  }
}
