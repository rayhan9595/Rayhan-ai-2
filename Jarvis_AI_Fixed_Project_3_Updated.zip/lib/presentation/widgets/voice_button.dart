import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../config/theme.dart';
import '../bloc/voice_bloc.dart';

class VoiceButton extends StatelessWidget {
  final double size;

  const VoiceButton({super.key, this.size = 64});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VoiceBloc, VoiceState>(
      builder: (context, state) {
        final isListening = state is VoiceListening;

        return GestureDetector(
          onTap: () {
            if (isListening) {
              context.read<VoiceBloc>().add(StopListeningEvent());
            } else {
              context.read<VoiceBloc>().add(StartListeningEvent());
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isListening ? AppTheme.error : AppTheme.primary,
              boxShadow: [
                BoxShadow(
                  color: (isListening ? AppTheme.error : AppTheme.primary).withOpacity(0.4),
                  blurRadius: isListening ? 20 : 10,
                  spreadRadius: isListening ? 5 : 2,
            child: Icon(
              isListening ? Icons.mic : Icons.mic_none,
              color: Colors.black,
              size: size * 0.4,