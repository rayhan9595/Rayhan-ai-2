import 'package:flutter/material.dart';
import '../../config/theme.dart';

class PermissionDialog extends StatelessWidget {
  final String permissionType;
  final String explanation;
  final VoidCallback onGrant;
  final VoidCallback onDeny;
  final VoidCallback onSettings;

  const PermissionDialog({
    super.key,
    required this.permissionType,
    required this.explanation,
    required this.onGrant,
    required this.onDeny,
    required this.onSettings,

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: AppTheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.warning.withOpacity(0.1),
                shape: BoxShape.circle,
              child: const Icon(Icons.security, color: AppTheme.warning, size: 40),
            const SizedBox(height: 16),
            Text(
              style: Theme.of(context).textTheme.titleLarge,
            const SizedBox(height: 8),
            Text(
              explanation,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppTheme.textSecondary),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: onGrant,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                foregroundColor: Colors.black,
                minimumSize: const Size(double.infinity, 48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: const Text(' '),
            const SizedBox(height: 8),
            TextButton(
              onPressed: onSettings,
              child: const Text(' ', style: TextStyle(color: AppTheme.primary)),
            TextButton(
              onPressed: onDeny,
              child: const Text('', style: TextStyle(color: AppTheme.textSecondary)),