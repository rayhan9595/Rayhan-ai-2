import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/usecases/self_update.dart';

abstract class SelfAwareEvent extends Equatable {
  @override
  List<Object?> get props => [];

class RequestSelfUpdateEvent extends SelfAwareEvent {
  final String userRequest;
  RequestSelfUpdateEvent(this.userRequest);
  @override
  List<Object?> get props => [userRequest];

class CheckStatusEvent extends SelfAwareEvent {}

abstract class SelfAwareState extends Equatable {
  @override
  List<Object?> get props => [];

class SelfAwareInitial extends SelfAwareState {}
class SelfAwareUpdating extends SelfAwareState {
  final String stage;
  SelfAwareUpdating(this.stage);
  @override
  List<Object?> get props => [stage];

class SelfAwareSuccess extends SelfAwareState {
  final String featureName;
  final String message;
  SelfAwareSuccess(this.featureName, this.message);
  @override
  List<Object?> get props => [featureName, message];

class SelfAwareError extends SelfAwareState {
  final String message;
  SelfAwareError(this.message);
  @override
  List<Object?> get props => [message];

class SelfAwareBloc extends Bloc<SelfAwareEvent, SelfAwareState> {
  final SelfUpdateUseCase _useCase = SelfUpdateUseCase();

  SelfAwareBloc() : super(SelfAwareInitial()) {
    on<<RequestSelfUpdateEvent>(_onRequest);
    on<<CheckStatusEvent>(_onCheckStatus);

  Future<void> _onRequest(RequestSelfUpdateEvent event, Emitter<SelfAwareState> emit) async {
    emit(SelfAwareUpdating('  ...'));
    await Future.delayed(const Duration(seconds: 1));

    emit(SelfAwareUpdating('  ...'));
    await Future.delayed(const Duration(seconds: 1));

    emit(SelfAwareUpdating('  ...'));

    try {
      final result = await _useCase.execute(event.userRequest);

      if (result.success) {
        emit(SelfAwareSuccess(result.featureName, result.message));
      } else {
        emit(SelfAwareError(result.message));
    } catch (e) {
      emit(SelfAwareError(e.toString()));

  Future<void> _onCheckStatus(CheckStatusEvent event, Emitter<SelfAwareState> emit) async {
    // Check deployed features status