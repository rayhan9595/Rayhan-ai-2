class Validators {
  static bool isValidPhoneNumber(String number) {
    final pattern = RegExp(r'^01[3-9]\d{8}$');
    return pattern.hasMatch(number);

  static bool isValidEmail(String email) {
    final pattern = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return pattern.hasMatch(email);

  static bool isValidPackageName(String name) {
    final pattern = RegExp(r'^([A-Za-z]{1}[A-Za-z\d_]*\.)+[A-Za-z][A-Za-z\d_]*$');
    return pattern.hasMatch(name);

  static String? required(String? value) {
    if (value == null || value.trim().isEmpty) {
      return '    ';
    return null;