import 'dart:collection';

class STMEntry {
  final String key;
  final dynamic value;
  final DateTime timestamp;
  final Duration ttl;

  STMEntry({
    required this.key,
    required this.value,
    DateTime? timestamp,
    this.ttl = const Duration(minutes: 10),
  }) : timestamp = timestamp ?? DateTime.now();

  bool get isExpired {
    return DateTime.now().difference(timestamp) > ttl;

class ShortTermMemory {
  static final ShortTermMemory _instance = ShortTermMemory._internal();
  factory ShortTermMemory() => _instance;
  ShortTermMemory._internal();

  final LinkedHashMap<String, STMEntry> _memory = LinkedHashMap();
  Timer? _cleanupTimer;

  void initialize() {
    _cleanupTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      _cleanup();

  void store(String key, dynamic value, {Duration? ttl}) {
    _memory[key] = STMEntry(
      key: key,
      value: value,
      ttl: ttl ?? const Duration(minutes: 10),

    // Keep only last 50 entries
    while (_memory.length > 50) {
      _memory.remove(_memory.keys.first);

  dynamic retrieve(String key) {
    final entry = _memory[key];
    if (entry == null || entry.isExpired) {
      _memory.remove(key);
      return null;
    return entry.value;

  Map<String, dynamic> getContext() {
    _cleanup();
    return Map.fromEntries(
      _memory.entries.map((e) => MapEntry(e.key, e.value.value)),

  void clear() {
    _memory.clear();

  void _cleanup() {
    _memory.removeWhere((_, entry) => entry.isExpired);

  void dispose() {
    _cleanupTimer?.cancel();