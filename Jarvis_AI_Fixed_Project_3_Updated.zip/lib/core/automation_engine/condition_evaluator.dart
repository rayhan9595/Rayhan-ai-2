import 'dart:convert';
import '../../services/api/weather_service.dart';
import '../../services/device/system_service.dart';

class ConditionEvaluator {
  static final ConditionEvaluator _instance = ConditionEvaluator._internal();
  factory ConditionEvaluator() => _instance;
  ConditionEvaluator._internal();

  final WeatherService _weather = WeatherService();
  final SystemService _system = SystemService();

  Future<bool> evaluate(Map<String, dynamic> condition) async {
    final type = condition['type'] as String;
    final operator = condition['operator'] as String;
    final value = condition['value'];

    dynamic actualValue;

    switch (type) {
      case 'time':
        actualValue = DateTime.now().hour;
        break;
      case 'day':
        actualValue = DateTime.now().weekday;
        break;
      case 'weather_temp':
        actualValue = await _weather.getCurrentTemperature();
        break;
      case 'weather_rain':
        actualValue = await _weather.getRainProbability();
        break;
      case 'battery':
        actualValue = await _system.getBatteryLevel();
        break;
      case 'wifi':
        actualValue = await _system.isWifiEnabled();
        break;
      case 'bluetooth':
        actualValue = await _system.isBluetoothEnabled();
        break;
      case 'location':
        actualValue = await _system.getCurrentLocationName();
        break;
      case 'app_running':
        actualValue = await _system.isAppRunning(value);
        break;
      default:
        return false;
    }

    return _compare(actualValue, operator, condition['expected'] ?? value);
  }

  bool _compare(dynamic actual, String operator, dynamic expected) {
    try {
      switch (operator) {
        case '==':
          return actual.toString() == expected.toString();
        case '!=':
          return actual.toString() != expected.toString();
        case '>':
          return (actual as num) > (expected as num);
        case '<':
          return (actual as num) < (expected as num);
        case '>=':
          return (actual as num) >= (expected as num);
        case '<=':
          return (actual as num) <= (expected as num);
        case 'contains':
          return actual.toString().contains(expected.toString());
        case 'startsWith':
          return actual.toString().startsWith(expected.toString());
        default:
          return false;
      }
    } catch (e) {
      return false;
    }
  }

  Future<bool> evaluateAll(List<Map<String, dynamic>> conditions,
      {String logic = 'AND'}) async {
    if (conditions.isEmpty) return true;

    final results = await Future.wait(
      conditions.map((c) => evaluate(c)),
    );

    if (logic == 'AND') {
      return results.every((r) => r);
    } else {
      return results.any((r) => r);
    }
  }
}
