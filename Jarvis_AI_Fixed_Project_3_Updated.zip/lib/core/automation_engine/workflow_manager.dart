import 'dart:async';
import 'dart:convert';
import 'package:workmanager/workmanager.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../../data/models/workflow.dart';
import '../../data/models/automation.dart';
import '../../data/repositories/workflow_repo.dart';
import 'trigger_detector.dart';
import 'condition_evaluator.dart';
import 'action_executor.dart';

class WorkflowManager {
  static final WorkflowManager _instance = WorkflowManager._internal();
  factory WorkflowManager() => _instance;
  WorkflowManager._internal();

  final TriggerDetector _trigger = TriggerDetector();
  final ConditionEvaluator _condition = ConditionEvaluator();
  final ActionExecutor _executor = ActionExecutor();
  final WorkflowRepository _repo = WorkflowRepository();
  StreamSubscription? _triggerSub;

  Future<void> initialize() async {
    await _trigger.initialize();

    _triggerSub = _trigger.triggerStream.listen((event) async {
      await _handleTrigger(event);
    });

    await _scheduleBackgroundTasks();
  }

  Future<void> _handleTrigger(TriggerEvent event) async {
    final workflows = await _repo.getActiveWorkflows();

    for (final workflow in workflows) {
      if (_matchesTrigger(workflow, event)) {
        final conditionsMet = await _condition.evaluateAll(
          workflow.conditions,
          logic: workflow.conditionLogic,
        );

        if (conditionsMet) {
          await executeWorkflow(workflow);
        }
      }
    }
  }

  bool _matchesTrigger(Workflow workflow, TriggerEvent event) {
    switch (event.type) {
      case TriggerType.voice:
        if (workflow.triggerType == 'voice') {
          final text = event.data['text']?.toString().toLowerCase() ?? '';
          return text.contains(workflow.triggerKeyword.toLowerCase());
        }
        break;
      case TriggerType.time:
        return workflow.triggerType == 'time';
      case TriggerType.location:
        return workflow.triggerType == 'location';
      case TriggerType.selfTrigger:
        return workflow.triggerType == 'self';
      default:
        return false;
    }
    return false;
  }

  Future<void> executeWorkflow(Workflow workflow) async {
    final results = await _executor.executeSequence(workflow.actions);
    final success = results.every((r) => r.success);

    await _repo.logExecution(workflow.id, success,
      errorMessage: success ? null : results.firstWhere((r) => !r.success).message);

    if (success && workflow.voiceConfirmation) {
      await _executor.execute(AutomationAction(
        type: 'speak',
        params: {'text': 'Workflow "${workflow.name}" completed successfully.'},
      ));
    }
  }

  Future<void> executeBackgroundTask(String task, Map<String, dynamic>? inputData) async {
    if (task == 'workflow_trigger' && inputData != null) {
      final workflowId = inputData['workflow_id'] as String?;
      if (workflowId != null) {
        final workflow = await _repo.getById(workflowId);
        if (workflow != null) {
          await executeWorkflow(workflow);
        }
      }
    }
  }

  Future<void> _scheduleBackgroundTasks() async {
    final timeWorkflows = await _repo.getTimeBasedWorkflows();

    for (final workflow in timeWorkflows) {
      if (workflow.nextRunTime != null) {
        final delay = workflow.nextRunTime!.difference(DateTime.now());
        if (!delay.isNegative) {
          Workmanager().registerOneOffTask(
            'workflow_${workflow.id}',
            'workflow_trigger',
            initialDelay: delay,
            inputData: {'workflow_id': workflow.id},
          );
        }
      }
    }
  }

  Future<void> addWorkflow(Workflow workflow) async {
    await _repo.insert(workflow);
    if (workflow.triggerType == 'time') {
      await _scheduleBackgroundTasks();
    }
    if (workflow.triggerType == 'location' && workflow.latitude != null) {
      _trigger.setupGeofence(
        workflow.id,
        workflow.latitude!,
        workflow.longitude!,
        workflow.radius ?? 100,
      );
    }
  }

  void dispose() {
    _triggerSub?.cancel();
    _trigger.dispose();
  }
}
