import 'dart:async';
import 'package:geolocator/geolocator.dart';
import '../../services/voice/wake_word.dart';
import '../../services/voice/stt_service.dart';

enum TriggerType {
  voice,
  time,
  location,
  gesture,
  selfTrigger,
  appLaunch,
  systemEvent,
}

class TriggerEvent {
  final TriggerType type;
  final Map<String, dynamic> data;
  final DateTime timestamp;

  TriggerEvent({
    required this.type,
    required this.data,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

class TriggerDetector {
  static final TriggerDetector _instance = TriggerDetector._internal();
  factory TriggerDetector() => _instance;
  TriggerDetector._internal();

  final _triggerController = StreamController<TriggerEvent>.broadcast();
  Stream<TriggerEvent> get triggerStream => _triggerController.stream;

  final WakeWordDetector _wakeWord = WakeWordDetector();
  final STTService _stt = STTService();
  bool _isListening = false;

  Future<void> initialize() async {
    await _wakeWord.initialize();
    await _stt.initialize();

    _wakeWord.onWakeWordDetected.listen((_) {
      _triggerController.add(TriggerEvent(
        type: TriggerType.voice,
        data: {'wakeWord': true},
      ));
      startVoiceListening();
    });
  }

  Future<void> startVoiceListening() async {
    if (_isListening) return;
    _isListening = true;

    final result = await _stt.listen();
    _isListening = false;

    if (result.isNotEmpty) {
      _triggerController.add(TriggerEvent(
        type: TriggerType.voice,
        data: {'text': result, 'confidence': 0.95},
      ));
    }
  }

  void scheduleTimeTrigger(String automationId, DateTime time) {
    final delay = time.difference(DateTime.now());
    if (delay.isNegative) return;

    Timer(delay, () {
      _triggerController.add(TriggerEvent(
        type: TriggerType.time,
        data: {'automationId': automationId, 'scheduledTime': time.toIso8601String()},
      ));
    });
  }

  void setupGeofence(String automationId, double lat, double lng, double radius) {
    Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10,
      ),
    ).listen((position) {
      final distance = Geolocator.distanceBetween(
        position.latitude, position.longitude, lat, lng);

      if (distance <= radius) {
        _triggerController.add(TriggerEvent(
          type: TriggerType.location,
          data: {
            'automationId': automationId,
            'latitude': lat,
            'longitude': lng,
            'currentDistance': distance,
          },
        ));
      }
    });
  }

  void triggerSelfEvent(String eventName, Map<String, dynamic> data) {
    _triggerController.add(TriggerEvent(
      type: TriggerType.selfTrigger,
      data: {'event': eventName, ...data},
    ));
  }

  void dispose() {
    _triggerController.close();
    _wakeWord.dispose();
    _stt.dispose();
  }
}
