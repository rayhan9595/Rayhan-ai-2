import '../../core/ai_brain/nlp_processor.dart';
import '../../data/models/self_update_request.dart';

class NeedAnalysis {
  final String featureName;
  final String description;
  final List<String> requiredModules;
  final bool requiresNewPermission;
  final String? permissionType;
  final int complexity; // 1-10

  NeedAnalysis({
    required this.featureName,
    required this.description,
    required this.requiredModules,
    this.requiresNewPermission = false,
    this.permissionType,
    required this.complexity,

class SelfAnalyzer {
  static final SelfAnalyzer _instance = SelfAnalyzer._internal();
  factory SelfAnalyzer() => _instance;
  SelfAnalyzer._internal();

  final NLPProcessor _nlp = NLPProcessor();

  Future<<NeedAnalysis> analyze(String userRequest) async {
    final prompt = '''
    Analyze this user request for a self-aware automation system.
    Determine what new feature/code is needed.

    Request: "$userRequest"

    Respond in JSON:
      "feature_name": "short_name",
      "description": "what to build",
      "required_modules": ["module1", "module2"],
      "requires_permission": true/false,
      "permission_type": "camera/location/etc or null",
      "complexity": 1-10

    try {
      // Use Gemini or local analysis
      return NeedAnalysis(
        featureName: 'auto_report',
        description: userRequest,
        requiredModules: ['scheduler', 'report_generator', 'notification'],
        requiresNewPermission: false,
        complexity: 5,
    } catch (e) {
      return _fallbackAnalysis(userRequest);

  NeedAnalysis _fallbackAnalysis(String request) {
    final lower = request.toLowerCase();

    if (lower.contains('') || lower.contains('report')) {
      return NeedAnalysis(
        featureName: 'weekly_report',
        description: 'Generate and send weekly automation reports',
        requiredModules: ['analytics', 'report_builder', 'scheduler'],
        complexity: 4,
    } else if (lower.contains('') || lower.contains('schedule')) {
      return NeedAnalysis(
        featureName: 'smart_scheduler',
        description: 'Advanced scheduling with conflict detection',
        requiredModules: ['calendar', 'conflict_resolver'],
        complexity: 6,

    return NeedAnalysis(
      featureName: 'custom_feature',
      description: request,
      requiredModules: ['core_engine'],
      complexity: 3,