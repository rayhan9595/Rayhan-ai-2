import 'dart:math';
import '../../config/constants.dart';
import '../../services/voice/tts_service.dart';

class ResponseGenerator {
  static final ResponseGenerator _instance = ResponseGenerator._internal();
  factory ResponseGenerator() => _instance;
  ResponseGenerator._internal();

  final TTSService _tts = TTSService();
  final Random _random = Random();

  Future<void> generate({
    required String intent,
    required bool success,
    Map<String, dynamic>? data,
    String? customMessage,
  }) async {
    String response;

    if (customMessage != null) {
      response = customMessage;
    } else if (success) {
      response = _getSuccessResponse(intent, data);
    } else {
      response = _getErrorResponse(intent, data);

    await _tts.speak(response);

  String _getSuccessResponse(String intent, Map<String, dynamic>? data) {
    final base = Constants.successReplies[_random.nextInt(Constants.successReplies.length)];

    switch (intent) {
      case 'open_app':
        return '${data?['app_name'] ?? ''}  , $base';
      case 'set_alarm':
        return '    ${data?['time'] ?? ''}';
      case 'set_reminder':
        return '  ${data?['message'] ?? ''}';
      case 'call_contact':
        return '${data?['contact'] ?? ''}-  ';
      case 'send_sms':
        return '  ';
      case 'check_weather':
        return '   ';
      case 'read_news':
        return '  ';
      case 'create_workflow':
        return '    ,   ';
      default:
        return base;

  String _getErrorResponse(String intent, Map<String, dynamic>? data) {
    final base = Constants.errorReplies[_random.nextInt(Constants.errorReplies.length)];

    switch (intent) {
      case 'open_app':
        return ' ,   । Play Store-   ';
      case 'set_alarm':
        return '    ,     ';
      case 'call_contact':
        return '  ';
      case 'permission_request':
        return ',     ,   ';
      default:
        return base;

  String generateSelfUpdateConfirmation(String featureName) {
    return ', $featureName      ।     ।';

  String generatePermissionExplanation(String permissionType) {
    final explanations = {
      'camera': '   QR     ',
      'location': '     ',
      'contacts': '    SMS ',
      'phone': '  ',
      'sms': ' ',
      'storage': '    ',
      'microphone': '  ',

    return ', ${explanations[permissionType] ?? '  '}  ।  ?';